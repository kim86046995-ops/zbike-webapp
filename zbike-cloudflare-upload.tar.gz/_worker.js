var jt=Object.defineProperty;var Xe=e=>{throw TypeError(e)};var Ct=(e,s,t)=>s in e?jt(e,s,{enumerable:!0,configurable:!0,writable:!0,value:t}):e[s]=t;var g=(e,s,t)=>Ct(e,typeof s!="symbol"?s+"":s,t),ke=(e,s,t)=>s.has(e)||Xe("Cannot "+t);var u=(e,s,t)=>(ke(e,s,"read from private field"),t?t.call(e):s.get(e)),v=(e,s,t)=>s.has(e)?Xe("Cannot add the same private member more than once"):s instanceof WeakSet?s.add(e):s.set(e,t),E=(e,s,t,r)=>(ke(e,s,"write to private field"),r?r.call(e,t):s.set(e,t),t),R=(e,s,t)=>(ke(e,s,"access private method"),t);var Ge=(e,s,t,r)=>({set _(n){E(e,s,n,t)},get _(){return u(e,s,r)}});import{existsSync as Nt,statSync as At,createReadStream as Ze}from"fs";import{join as Qe}from"path";import{versions as Lt}from"process";import{Readable as Mt}from"stream";var et=(e,s,t)=>(r,n)=>{let a=-1;return o(0);async function o(i){if(i<=a)throw new Error("next() called multiple times");a=i;let c,d=!1,l;if(e[i]?(l=e[i][0][0],r.req.routeIndex=i):l=i===e.length&&n||void 0,l)try{c=await l(r,()=>o(i+1))}catch(m){if(m instanceof Error&&s)r.error=m,c=await s(m,r),d=!0;else throw m}else r.finalized===!1&&t&&(c=await t(r));return c&&(r.finalized===!1||d)&&(r.res=c),r}},Bt=Symbol(),Pt=async(e,s=Object.create(null))=>{const{all:t=!1,dot:r=!1}=s,a=(e instanceof ft?e.raw.headers:e.headers).get("Content-Type");return a!=null&&a.startsWith("multipart/form-data")||a!=null&&a.startsWith("application/x-www-form-urlencoded")?Ht(e,{all:t,dot:r}):{}};async function Ht(e,s){const t=await e.formData();return t?Ut(t,s):{}}function Ut(e,s){const t=Object.create(null);return e.forEach((r,n)=>{s.all||n.endsWith("[]")?Ft(t,n,r):t[n]=r}),s.dot&&Object.entries(t).forEach(([r,n])=>{r.includes(".")&&(Wt(t,r,n),delete t[r])}),t}var Ft=(e,s,t)=>{e[s]!==void 0?Array.isArray(e[s])?e[s].push(t):e[s]=[e[s],t]:s.endsWith("[]")?e[s]=[t]:e[s]=t},Wt=(e,s,t)=>{let r=e;const n=s.split(".");n.forEach((a,o)=>{o===n.length-1?r[a]=t:((!r[a]||typeof r[a]!="object"||Array.isArray(r[a])||r[a]instanceof File)&&(r[a]=Object.create(null)),r=r[a])})},ut=e=>{const s=e.split("/");return s[0]===""&&s.shift(),s},$t=e=>{const{groups:s,path:t}=kt(e),r=ut(t);return qt(r,s)},kt=e=>{const s=[];return e=e.replace(/\{[^}]+\}/g,(t,r)=>{const n=`@${r}`;return s.push([n,t]),n}),{groups:s,path:e}},qt=(e,s)=>{for(let t=s.length-1;t>=0;t--){const[r]=s[t];for(let n=e.length-1;n>=0;n--)if(e[n].includes(r)){e[n]=e[n].replace(r,s[t][1]);break}}return e},Me={},Kt=(e,s)=>{if(e==="*")return"*";const t=e.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);if(t){const r=`${e}#${s}`;return Me[r]||(t[2]?Me[r]=s&&s[0]!==":"&&s[0]!=="*"?[r,t[1],new RegExp(`^${t[2]}(?=/${s})`)]:[e,t[1],new RegExp(`^${t[2]}$`)]:Me[r]=[e,t[1],!0]),Me[r]}return null},Je=(e,s)=>{try{return s(e)}catch{return e.replace(/(?:%[0-9A-Fa-f]{2})+/g,t=>{try{return s(t)}catch{return t}})}},Yt=e=>Je(e,decodeURI),mt=e=>{const s=e.url,t=s.indexOf("/",s.indexOf(":")+4);let r=t;for(;r<s.length;r++){const n=s.charCodeAt(r);if(n===37){const a=s.indexOf("?",r),o=s.slice(t,a===-1?void 0:a);return Yt(o.includes("%25")?o.replace(/%25/g,"%2525"):o)}else if(n===63)break}return s.slice(t,r)},Vt=e=>{const s=mt(e);return s.length>1&&s.at(-1)==="/"?s.slice(0,-1):s},_e=(e,s,...t)=>(t.length&&(s=_e(s,...t)),`${(e==null?void 0:e[0])==="/"?"":"/"}${e}${s==="/"?"":`${(e==null?void 0:e.at(-1))==="/"?"":"/"}${(s==null?void 0:s[0])==="/"?s.slice(1):s}`}`),pt=e=>{if(e.charCodeAt(e.length-1)!==63||!e.includes(":"))return null;const s=e.split("/"),t=[];let r="";return s.forEach(n=>{if(n!==""&&!/\:/.test(n))r+="/"+n;else if(/\:/.test(n))if(/\?/.test(n)){t.length===0&&r===""?t.push("/"):t.push(r);const a=n.replace("?","");r+="/"+a,t.push(r)}else r+="/"+n}),t.filter((n,a,o)=>o.indexOf(n)===a)},qe=e=>/[%+]/.test(e)?(e.indexOf("+")!==-1&&(e=e.replace(/\+/g," ")),e.indexOf("%")!==-1?Je(e,ht):e):e,_t=(e,s,t)=>{let r;if(!t&&s&&!/[%+]/.test(s)){let o=e.indexOf("?",8);if(o===-1)return;for(e.startsWith(s,o+1)||(o=e.indexOf(`&${s}`,o+1));o!==-1;){const i=e.charCodeAt(o+s.length+1);if(i===61){const c=o+s.length+2,d=e.indexOf("&",c);return qe(e.slice(c,d===-1?void 0:d))}else if(i==38||isNaN(i))return"";o=e.indexOf(`&${s}`,o+1)}if(r=/[%+]/.test(e),!r)return}const n={};r??(r=/[%+]/.test(e));let a=e.indexOf("?",8);for(;a!==-1;){const o=e.indexOf("&",a+1);let i=e.indexOf("=",a);i>o&&o!==-1&&(i=-1);let c=e.slice(a+1,i===-1?o===-1?void 0:o:i);if(r&&(c=qe(c)),a=o,c==="")continue;let d;i===-1?d="":(d=e.slice(i+1,o===-1?void 0:o),r&&(d=qe(d))),t?(n[c]&&Array.isArray(n[c])||(n[c]=[]),n[c].push(d)):n[c]??(n[c]=d)}return s?n[s]:n},zt=_t,Jt=(e,s)=>_t(e,s,!0),ht=decodeURIComponent,tt=e=>Je(e,ht),Ee,U,J,Et,gt,Ve,G,at,ft=(at=class{constructor(e,s="/",t=[[]]){v(this,J);g(this,"raw");v(this,Ee);v(this,U);g(this,"routeIndex",0);g(this,"path");g(this,"bodyCache",{});v(this,G,e=>{const{bodyCache:s,raw:t}=this,r=s[e];if(r)return r;const n=Object.keys(s)[0];return n?s[n].then(a=>(n==="json"&&(a=JSON.stringify(a)),new Response(a)[e]())):s[e]=t[e]()});this.raw=e,this.path=s,E(this,U,t),E(this,Ee,{})}param(e){return e?R(this,J,Et).call(this,e):R(this,J,gt).call(this)}query(e){return zt(this.url,e)}queries(e){return Jt(this.url,e)}header(e){if(e)return this.raw.headers.get(e)??void 0;const s={};return this.raw.headers.forEach((t,r)=>{s[r]=t}),s}async parseBody(e){var s;return(s=this.bodyCache).parsedBody??(s.parsedBody=await Pt(this,e))}json(){return u(this,G).call(this,"text").then(e=>JSON.parse(e))}text(){return u(this,G).call(this,"text")}arrayBuffer(){return u(this,G).call(this,"arrayBuffer")}blob(){return u(this,G).call(this,"blob")}formData(){return u(this,G).call(this,"formData")}addValidatedData(e,s){u(this,Ee)[e]=s}valid(e){return u(this,Ee)[e]}get url(){return this.raw.url}get method(){return this.raw.method}get[Bt](){return u(this,U)}get matchedRoutes(){return u(this,U)[0].map(([[,e]])=>e)}get routePath(){return u(this,U)[0].map(([[,e]])=>e)[this.routeIndex].path}},Ee=new WeakMap,U=new WeakMap,J=new WeakSet,Et=function(e){const s=u(this,U)[0][this.routeIndex][1][e],t=R(this,J,Ve).call(this,s);return t&&/\%/.test(t)?tt(t):t},gt=function(){const e={},s=Object.keys(u(this,U)[0][this.routeIndex][1]);for(const t of s){const r=R(this,J,Ve).call(this,u(this,U)[0][this.routeIndex][1][t]);r!==void 0&&(e[t]=/\%/.test(r)?tt(r):r)}return e},Ve=function(e){return u(this,U)[1]?u(this,U)[1][e]:e},G=new WeakMap,at),Xt={Stringify:1},bt=async(e,s,t,r,n)=>{typeof e=="object"&&!(e instanceof String)&&(e instanceof Promise||(e=e.toString()),e instanceof Promise&&(e=await e));const a=e.callbacks;return a!=null&&a.length?(n?n[0]+=e:n=[e],Promise.all(a.map(i=>i({phase:s,buffer:n,context:r}))).then(i=>Promise.all(i.filter(Boolean).map(c=>bt(c,s,!1,r,n))).then(()=>n[0]))):Promise.resolve(e)},Gt="text/plain; charset=UTF-8",Ke=(e,s)=>({"Content-Type":e,...s}),Ie,je,K,ge,Y,B,Ce,be,ye,oe,Ne,Ae,Z,he,ot,Zt=(ot=class{constructor(e,s){v(this,Z);v(this,Ie);v(this,je);g(this,"env",{});v(this,K);g(this,"finalized",!1);g(this,"error");v(this,ge);v(this,Y);v(this,B);v(this,Ce);v(this,be);v(this,ye);v(this,oe);v(this,Ne);v(this,Ae);g(this,"render",(...e)=>(u(this,be)??E(this,be,s=>this.html(s)),u(this,be).call(this,...e)));g(this,"setLayout",e=>E(this,Ce,e));g(this,"getLayout",()=>u(this,Ce));g(this,"setRenderer",e=>{E(this,be,e)});g(this,"header",(e,s,t)=>{this.finalized&&E(this,B,new Response(u(this,B).body,u(this,B)));const r=u(this,B)?u(this,B).headers:u(this,oe)??E(this,oe,new Headers);s===void 0?r.delete(e):t!=null&&t.append?r.append(e,s):r.set(e,s)});g(this,"status",e=>{E(this,ge,e)});g(this,"set",(e,s)=>{u(this,K)??E(this,K,new Map),u(this,K).set(e,s)});g(this,"get",e=>u(this,K)?u(this,K).get(e):void 0);g(this,"newResponse",(...e)=>R(this,Z,he).call(this,...e));g(this,"body",(e,s,t)=>R(this,Z,he).call(this,e,s,t));g(this,"text",(e,s,t)=>!u(this,oe)&&!u(this,ge)&&!s&&!t&&!this.finalized?new Response(e):R(this,Z,he).call(this,e,s,Ke(Gt,t)));g(this,"json",(e,s,t)=>R(this,Z,he).call(this,JSON.stringify(e),s,Ke("application/json",t)));g(this,"html",(e,s,t)=>{const r=n=>R(this,Z,he).call(this,n,s,Ke("text/html; charset=UTF-8",t));return typeof e=="object"?bt(e,Xt.Stringify,!1,{}).then(r):r(e)});g(this,"redirect",(e,s)=>{const t=String(e);return this.header("Location",/[^\x00-\xFF]/.test(t)?encodeURI(t):t),this.newResponse(null,s??302)});g(this,"notFound",()=>(u(this,ye)??E(this,ye,()=>new Response),u(this,ye).call(this,this)));E(this,Ie,e),s&&(E(this,Y,s.executionCtx),this.env=s.env,E(this,ye,s.notFoundHandler),E(this,Ae,s.path),E(this,Ne,s.matchResult))}get req(){return u(this,je)??E(this,je,new ft(u(this,Ie),u(this,Ae),u(this,Ne))),u(this,je)}get event(){if(u(this,Y)&&"respondWith"in u(this,Y))return u(this,Y);throw Error("This context has no FetchEvent")}get executionCtx(){if(u(this,Y))return u(this,Y);throw Error("This context has no ExecutionContext")}get res(){return u(this,B)||E(this,B,new Response(null,{headers:u(this,oe)??E(this,oe,new Headers)}))}set res(e){if(u(this,B)&&e){e=new Response(e.body,e);for(const[s,t]of u(this,B).headers.entries())if(s!=="content-type")if(s==="set-cookie"){const r=u(this,B).headers.getSetCookie();e.headers.delete("set-cookie");for(const n of r)e.headers.append("set-cookie",n)}else e.headers.set(s,t)}E(this,B,e),this.finalized=!0}get var(){return u(this,K)?Object.fromEntries(u(this,K)):{}}},Ie=new WeakMap,je=new WeakMap,K=new WeakMap,ge=new WeakMap,Y=new WeakMap,B=new WeakMap,Ce=new WeakMap,be=new WeakMap,ye=new WeakMap,oe=new WeakMap,Ne=new WeakMap,Ae=new WeakMap,Z=new WeakSet,he=function(e,s,t){const r=u(this,B)?new Headers(u(this,B).headers):u(this,oe)??new Headers;if(typeof s=="object"&&"headers"in s){const a=s.headers instanceof Headers?s.headers:new Headers(s.headers);for(const[o,i]of a)o.toLowerCase()==="set-cookie"?r.append(o,i):r.set(o,i)}if(t)for(const[a,o]of Object.entries(t))if(typeof o=="string")r.set(a,o);else{r.delete(a);for(const i of o)r.append(a,i)}const n=typeof s=="number"?s:(s==null?void 0:s.status)??u(this,ge);return new Response(e,{status:n,headers:r})},ot),O="ALL",Qt="all",es=["get","post","put","delete","options","patch"],yt="Can not add a route since the matcher is already built.",vt=class extends Error{},ts="__COMPOSED_HANDLER",ss=e=>e.text("404 Not Found",404),st=(e,s)=>{if("getResponse"in e){const t=e.getResponse();return s.newResponse(t.body,t)}return console.error(e),s.text("Internal Server Error",500)},W,I,wt,$,ne,Be,Pe,ve,rs=(ve=class{constructor(s={}){v(this,I);g(this,"get");g(this,"post");g(this,"put");g(this,"delete");g(this,"options");g(this,"patch");g(this,"all");g(this,"on");g(this,"use");g(this,"router");g(this,"getPath");g(this,"_basePath","/");v(this,W,"/");g(this,"routes",[]);v(this,$,ss);g(this,"errorHandler",st);g(this,"onError",s=>(this.errorHandler=s,this));g(this,"notFound",s=>(E(this,$,s),this));g(this,"fetch",(s,...t)=>R(this,I,Pe).call(this,s,t[1],t[0],s.method));g(this,"request",(s,t,r,n)=>s instanceof Request?this.fetch(t?new Request(s,t):s,r,n):(s=s.toString(),this.fetch(new Request(/^https?:\/\//.test(s)?s:`http://localhost${_e("/",s)}`,t),r,n)));g(this,"fire",()=>{addEventListener("fetch",s=>{s.respondWith(R(this,I,Pe).call(this,s.request,s,void 0,s.request.method))})});[...es,Qt].forEach(a=>{this[a]=(o,...i)=>(typeof o=="string"?E(this,W,o):R(this,I,ne).call(this,a,u(this,W),o),i.forEach(c=>{R(this,I,ne).call(this,a,u(this,W),c)}),this)}),this.on=(a,o,...i)=>{for(const c of[o].flat()){E(this,W,c);for(const d of[a].flat())i.map(l=>{R(this,I,ne).call(this,d.toUpperCase(),u(this,W),l)})}return this},this.use=(a,...o)=>(typeof a=="string"?E(this,W,a):(E(this,W,"*"),o.unshift(a)),o.forEach(i=>{R(this,I,ne).call(this,O,u(this,W),i)}),this);const{strict:r,...n}=s;Object.assign(this,n),this.getPath=r??!0?s.getPath??mt:Vt}route(s,t){const r=this.basePath(s);return t.routes.map(n=>{var o;let a;t.errorHandler===st?a=n.handler:(a=async(i,c)=>(await et([],t.errorHandler)(i,()=>n.handler(i,c))).res,a[ts]=n.handler),R(o=r,I,ne).call(o,n.method,n.path,a)}),this}basePath(s){const t=R(this,I,wt).call(this);return t._basePath=_e(this._basePath,s),t}mount(s,t,r){let n,a;r&&(typeof r=="function"?a=r:(a=r.optionHandler,r.replaceRequest===!1?n=c=>c:n=r.replaceRequest));const o=a?c=>{const d=a(c);return Array.isArray(d)?d:[d]}:c=>{let d;try{d=c.executionCtx}catch{}return[c.env,d]};n||(n=(()=>{const c=_e(this._basePath,s),d=c==="/"?0:c.length;return l=>{const m=new URL(l.url);return m.pathname=m.pathname.slice(d)||"/",new Request(m,l)}})());const i=async(c,d)=>{const l=await t(n(c.req.raw),...o(c));if(l)return l;await d()};return R(this,I,ne).call(this,O,_e(s,"*"),i),this}},W=new WeakMap,I=new WeakSet,wt=function(){const s=new ve({router:this.router,getPath:this.getPath});return s.errorHandler=this.errorHandler,E(s,$,u(this,$)),s.routes=this.routes,s},$=new WeakMap,ne=function(s,t,r){s=s.toUpperCase(),t=_e(this._basePath,t);const n={basePath:this._basePath,path:t,method:s,handler:r};this.router.add(s,t,[r,n]),this.routes.push(n)},Be=function(s,t){if(s instanceof Error)return this.errorHandler(s,t);throw s},Pe=function(s,t,r,n){if(n==="HEAD")return(async()=>new Response(null,await R(this,I,Pe).call(this,s,t,r,"GET")))();const a=this.getPath(s,{env:r}),o=this.router.match(n,a),i=new Zt(s,{path:a,matchResult:o,env:r,executionCtx:t,notFoundHandler:u(this,$)});if(o[0].length===1){let d;try{d=o[0][0][0][0](i,async()=>{i.res=await u(this,$).call(this,i)})}catch(l){return R(this,I,Be).call(this,l,i)}return d instanceof Promise?d.then(l=>l||(i.finalized?i.res:u(this,$).call(this,i))).catch(l=>R(this,I,Be).call(this,l,i)):d??u(this,$).call(this,i)}const c=et(o[0],this.errorHandler,u(this,$));return(async()=>{try{const d=await c(i);if(!d.finalized)throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");return d.res}catch(d){return R(this,I,Be).call(this,d,i)}})()},ve),Rt=[];function ns(e,s){const t=this.buildAllMatchers(),r=((n,a)=>{const o=t[n]||t[O],i=o[2][a];if(i)return i;const c=a.match(o[0]);if(!c)return[[],Rt];const d=c.indexOf("",1);return[o[1][d],c]});return this.match=r,r(e,s)}var Ue="[^/]+",De=".*",xe="(?:|/.*)",fe=Symbol(),as=new Set(".\\+*[^]$()");function os(e,s){return e.length===1?s.length===1?e<s?-1:1:-1:s.length===1||e===De||e===xe?1:s===De||s===xe?-1:e===Ue?1:s===Ue?-1:e.length===s.length?e<s?-1:1:s.length-e.length}var ie,ce,k,ue,is=(ue=class{constructor(){v(this,ie);v(this,ce);v(this,k,Object.create(null))}insert(s,t,r,n,a){if(s.length===0){if(u(this,ie)!==void 0)throw fe;if(a)return;E(this,ie,t);return}const[o,...i]=s,c=o==="*"?i.length===0?["","",De]:["","",Ue]:o==="/*"?["","",xe]:o.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);let d;if(c){const l=c[1];let m=c[2]||Ue;if(l&&c[2]&&(m===".*"||(m=m.replace(/^\((?!\?:)(?=[^)]+\)$)/,"(?:"),/\((?!\?:)/.test(m))))throw fe;if(d=u(this,k)[m],!d){if(Object.keys(u(this,k)).some(_=>_!==De&&_!==xe))throw fe;if(a)return;d=u(this,k)[m]=new ue,l!==""&&E(d,ce,n.varIndex++)}!a&&l!==""&&r.push([l,u(d,ce)])}else if(d=u(this,k)[o],!d){if(Object.keys(u(this,k)).some(l=>l.length>1&&l!==De&&l!==xe))throw fe;if(a)return;d=u(this,k)[o]=new ue}d.insert(i,t,r,n,a)}buildRegExpStr(){const t=Object.keys(u(this,k)).sort(os).map(r=>{const n=u(this,k)[r];return(typeof u(n,ce)=="number"?`(${r})@${u(n,ce)}`:as.has(r)?`\\${r}`:r)+n.buildRegExpStr()});return typeof u(this,ie)=="number"&&t.unshift(`#${u(this,ie)}`),t.length===0?"":t.length===1?t[0]:"(?:"+t.join("|")+")"}},ie=new WeakMap,ce=new WeakMap,k=new WeakMap,ue),Fe,Le,it,cs=(it=class{constructor(){v(this,Fe,{varIndex:0});v(this,Le,new is)}insert(e,s,t){const r=[],n=[];for(let o=0;;){let i=!1;if(e=e.replace(/\{[^}]+\}/g,c=>{const d=`@\\${o}`;return n[o]=[d,c],o++,i=!0,d}),!i)break}const a=e.match(/(?::[^\/]+)|(?:\/\*$)|./g)||[];for(let o=n.length-1;o>=0;o--){const[i]=n[o];for(let c=a.length-1;c>=0;c--)if(a[c].indexOf(i)!==-1){a[c]=a[c].replace(i,n[o][1]);break}}return u(this,Le).insert(a,s,r,u(this,Fe),t),r}buildRegExp(){let e=u(this,Le).buildRegExpStr();if(e==="")return[/^$/,[],[]];let s=0;const t=[],r=[];return e=e.replace(/#(\d+)|@(\d+)|\.\*\$/g,(n,a,o)=>a!==void 0?(t[++s]=Number(a),"$()"):(o!==void 0&&(r[Number(o)]=++s),"")),[new RegExp(`^${e}`),t,r]}},Fe=new WeakMap,Le=new WeakMap,it),ds=[/^$/,[],Object.create(null)],He=Object.create(null);function Tt(e){return He[e]??(He[e]=new RegExp(e==="*"?"":`^${e.replace(/\/\*$|([.\\+*[^\]$()])/g,(s,t)=>t?`\\${t}`:"(?:|/.*)")}$`))}function ls(){He=Object.create(null)}function us(e){var d;const s=new cs,t=[];if(e.length===0)return ds;const r=e.map(l=>[!/\*|\/:/.test(l[0]),...l]).sort(([l,m],[_,h])=>l?1:_?-1:m.length-h.length),n=Object.create(null);for(let l=0,m=-1,_=r.length;l<_;l++){const[h,b,T]=r[l];h?n[b]=[T.map(([w])=>[w,Object.create(null)]),Rt]:m++;let y;try{y=s.insert(b,m,h)}catch(w){throw w===fe?new vt(b):w}h||(t[m]=T.map(([w,S])=>{const F=Object.create(null);for(S-=1;S>=0;S--){const[C,M]=y[S];F[C]=M}return[w,F]}))}const[a,o,i]=s.buildRegExp();for(let l=0,m=t.length;l<m;l++)for(let _=0,h=t[l].length;_<h;_++){const b=(d=t[l][_])==null?void 0:d[1];if(!b)continue;const T=Object.keys(b);for(let y=0,w=T.length;y<w;y++)b[T[y]]=i[b[T[y]]]}const c=[];for(const l in o)c[l]=t[o[l]];return[a,c,n]}function pe(e,s){if(e){for(const t of Object.keys(e).sort((r,n)=>n.length-r.length))if(Tt(t).test(s))return[...e[t]]}}var Q,ee,We,St,ct,ms=(ct=class{constructor(){v(this,We);g(this,"name","RegExpRouter");v(this,Q);v(this,ee);g(this,"match",ns);E(this,Q,{[O]:Object.create(null)}),E(this,ee,{[O]:Object.create(null)})}add(e,s,t){var i;const r=u(this,Q),n=u(this,ee);if(!r||!n)throw new Error(yt);r[e]||[r,n].forEach(c=>{c[e]=Object.create(null),Object.keys(c[O]).forEach(d=>{c[e][d]=[...c[O][d]]})}),s==="/*"&&(s="*");const a=(s.match(/\/:/g)||[]).length;if(/\*$/.test(s)){const c=Tt(s);e===O?Object.keys(r).forEach(d=>{var l;(l=r[d])[s]||(l[s]=pe(r[d],s)||pe(r[O],s)||[])}):(i=r[e])[s]||(i[s]=pe(r[e],s)||pe(r[O],s)||[]),Object.keys(r).forEach(d=>{(e===O||e===d)&&Object.keys(r[d]).forEach(l=>{c.test(l)&&r[d][l].push([t,a])})}),Object.keys(n).forEach(d=>{(e===O||e===d)&&Object.keys(n[d]).forEach(l=>c.test(l)&&n[d][l].push([t,a]))});return}const o=pt(s)||[s];for(let c=0,d=o.length;c<d;c++){const l=o[c];Object.keys(n).forEach(m=>{var _;(e===O||e===m)&&((_=n[m])[l]||(_[l]=[...pe(r[m],l)||pe(r[O],l)||[]]),n[m][l].push([t,a-d+c+1]))})}}buildAllMatchers(){const e=Object.create(null);return Object.keys(u(this,ee)).concat(Object.keys(u(this,Q))).forEach(s=>{e[s]||(e[s]=R(this,We,St).call(this,s))}),E(this,Q,E(this,ee,void 0)),ls(),e}},Q=new WeakMap,ee=new WeakMap,We=new WeakSet,St=function(e){const s=[];let t=e===O;return[u(this,Q),u(this,ee)].forEach(r=>{const n=r[e]?Object.keys(r[e]).map(a=>[a,r[e][a]]):[];n.length!==0?(t||(t=!0),s.push(...n)):e!==O&&s.push(...Object.keys(r[O]).map(a=>[a,r[O][a]]))}),t?us(s):null},ct),te,V,dt,ps=(dt=class{constructor(e){g(this,"name","SmartRouter");v(this,te,[]);v(this,V,[]);E(this,te,e.routers)}add(e,s,t){if(!u(this,V))throw new Error(yt);u(this,V).push([e,s,t])}match(e,s){if(!u(this,V))throw new Error("Fatal error");const t=u(this,te),r=u(this,V),n=t.length;let a=0,o;for(;a<n;a++){const i=t[a];try{for(let c=0,d=r.length;c<d;c++)i.add(...r[c]);o=i.match(e,s)}catch(c){if(c instanceof vt)continue;throw c}this.match=i.match.bind(i),E(this,te,[i]),E(this,V,void 0);break}if(a===n)throw new Error("Fatal error");return this.name=`SmartRouter + ${this.activeRouter.name}`,o}get activeRouter(){if(u(this,V)||u(this,te).length!==1)throw new Error("No active router has been determined yet.");return u(this,te)[0]}},te=new WeakMap,V=new WeakMap,dt),Se=Object.create(null),se,L,de,we,N,z,ae,Re,_s=(Re=class{constructor(s,t,r){v(this,z);v(this,se);v(this,L);v(this,de);v(this,we,0);v(this,N,Se);if(E(this,L,r||Object.create(null)),E(this,se,[]),s&&t){const n=Object.create(null);n[s]={handler:t,possibleKeys:[],score:0},E(this,se,[n])}E(this,de,[])}insert(s,t,r){E(this,we,++Ge(this,we)._);let n=this;const a=$t(t),o=[];for(let i=0,c=a.length;i<c;i++){const d=a[i],l=a[i+1],m=Kt(d,l),_=Array.isArray(m)?m[0]:d;if(_ in u(n,L)){n=u(n,L)[_],m&&o.push(m[1]);continue}u(n,L)[_]=new Re,m&&(u(n,de).push(m),o.push(m[1])),n=u(n,L)[_]}return u(n,se).push({[s]:{handler:r,possibleKeys:o.filter((i,c,d)=>d.indexOf(i)===c),score:u(this,we)}}),n}search(s,t){var c;const r=[];E(this,N,Se);let a=[this];const o=ut(t),i=[];for(let d=0,l=o.length;d<l;d++){const m=o[d],_=d===l-1,h=[];for(let b=0,T=a.length;b<T;b++){const y=a[b],w=u(y,L)[m];w&&(E(w,N,u(y,N)),_?(u(w,L)["*"]&&r.push(...R(this,z,ae).call(this,u(w,L)["*"],s,u(y,N))),r.push(...R(this,z,ae).call(this,w,s,u(y,N)))):h.push(w));for(let S=0,F=u(y,de).length;S<F;S++){const C=u(y,de)[S],M=u(y,N)===Se?{}:{...u(y,N)};if(C==="*"){const P=u(y,L)["*"];P&&(r.push(...R(this,z,ae).call(this,P,s,u(y,N))),E(P,N,M),h.push(P));continue}const[q,H,A]=C;if(!m&&!(A instanceof RegExp))continue;const x=u(y,L)[q],X=o.slice(d).join("/");if(A instanceof RegExp){const P=A.exec(X);if(P){if(M[H]=P[0],r.push(...R(this,z,ae).call(this,x,s,u(y,N),M)),Object.keys(u(x,L)).length){E(x,N,M);const j=((c=P[0].match(/\//))==null?void 0:c.length)??0;(i[j]||(i[j]=[])).push(x)}continue}}(A===!0||A.test(m))&&(M[H]=m,_?(r.push(...R(this,z,ae).call(this,x,s,M,u(y,N))),u(x,L)["*"]&&r.push(...R(this,z,ae).call(this,u(x,L)["*"],s,M,u(y,N)))):(E(x,N,M),h.push(x)))}}a=h.concat(i.shift()??[])}return r.length>1&&r.sort((d,l)=>d.score-l.score),[r.map(({handler:d,params:l})=>[d,l])]}},se=new WeakMap,L=new WeakMap,de=new WeakMap,we=new WeakMap,N=new WeakMap,z=new WeakSet,ae=function(s,t,r,n){const a=[];for(let o=0,i=u(s,se).length;o<i;o++){const c=u(s,se)[o],d=c[t]||c[O],l={};if(d!==void 0&&(d.params=Object.create(null),a.push(d),r!==Se||n&&n!==Se))for(let m=0,_=d.possibleKeys.length;m<_;m++){const h=d.possibleKeys[m],b=l[d.score];d.params[h]=n!=null&&n[h]&&!b?n[h]:r[h]??(n==null?void 0:n[h]),l[d.score]=!0}}return a},Re),le,lt,hs=(lt=class{constructor(){g(this,"name","TrieRouter");v(this,le);E(this,le,new _s)}add(e,s,t){const r=pt(s);if(r){for(let n=0,a=r.length;n<a;n++)u(this,le).insert(e,r[n],t);return}u(this,le).insert(e,s,t)}match(e,s){return u(this,le).search(e,s)}},le=new WeakMap,lt),Dt=class extends rs{constructor(e={}){super(e),this.router=e.router??new ps({routers:[new ms,new hs]})}},fs=e=>{const t={...{origin:"*",allowMethods:["GET","HEAD","PUT","POST","DELETE","PATCH"],allowHeaders:[],exposeHeaders:[]},...e},r=(a=>typeof a=="string"?a==="*"?()=>a:o=>a===o?o:null:typeof a=="function"?a:o=>a.includes(o)?o:null)(t.origin),n=(a=>typeof a=="function"?a:Array.isArray(a)?()=>a:()=>[])(t.allowMethods);return async function(o,i){var l;function c(m,_){o.res.headers.set(m,_)}const d=await r(o.req.header("origin")||"",o);if(d&&c("Access-Control-Allow-Origin",d),t.credentials&&c("Access-Control-Allow-Credentials","true"),(l=t.exposeHeaders)!=null&&l.length&&c("Access-Control-Expose-Headers",t.exposeHeaders.join(",")),o.req.method==="OPTIONS"){t.origin!=="*"&&c("Vary","Origin"),t.maxAge!=null&&c("Access-Control-Max-Age",t.maxAge.toString());const m=await n(o.req.header("origin")||"",o);m.length&&c("Access-Control-Allow-Methods",m.join(","));let _=t.allowHeaders;if(!(_!=null&&_.length)){const h=o.req.header("Access-Control-Request-Headers");h&&(_=h.split(/\s*,\s*/))}return _!=null&&_.length&&(c("Access-Control-Allow-Headers",_.join(",")),o.res.headers.append("Vary","Access-Control-Request-Headers")),o.res.headers.delete("Content-Length"),o.res.headers.delete("Content-Type"),new Response(null,{headers:o.res.headers,status:204,statusText:"No Content"})}await i(),t.origin!=="*"&&o.header("Vary","Origin",{append:!0})}},Es=(e,s=bs)=>{const t=/\.([a-zA-Z0-9]+?)$/,r=e.match(t);if(!r)return;let n=s[r[1]];return n&&n.startsWith("text")&&(n+="; charset=utf-8"),n},gs={aac:"audio/aac",avi:"video/x-msvideo",avif:"image/avif",av1:"video/av1",bin:"application/octet-stream",bmp:"image/bmp",css:"text/css",csv:"text/csv",eot:"application/vnd.ms-fontobject",epub:"application/epub+zip",gif:"image/gif",gz:"application/gzip",htm:"text/html",html:"text/html",ico:"image/x-icon",ics:"text/calendar",jpeg:"image/jpeg",jpg:"image/jpeg",js:"text/javascript",json:"application/json",jsonld:"application/ld+json",map:"application/json",mid:"audio/x-midi",midi:"audio/x-midi",mjs:"text/javascript",mp3:"audio/mpeg",mp4:"video/mp4",mpeg:"video/mpeg",oga:"audio/ogg",ogv:"video/ogg",ogx:"application/ogg",opus:"audio/opus",otf:"font/otf",pdf:"application/pdf",png:"image/png",rtf:"application/rtf",svg:"image/svg+xml",tif:"image/tiff",tiff:"image/tiff",ts:"video/mp2t",ttf:"font/ttf",txt:"text/plain",wasm:"application/wasm",webm:"video/webm",weba:"audio/webm",webmanifest:"application/manifest+json",webp:"image/webp",woff:"font/woff",woff2:"font/woff2",xhtml:"application/xhtml+xml",xml:"application/xml",zip:"application/zip","3gp":"video/3gpp","3g2":"video/3gpp2",gltf:"model/gltf+json",glb:"model/gltf-binary"},bs=gs,ys=/^\s*(?:text\/[^;\s]+|application\/(?:javascript|json|xml|xml-dtd|ecmascript|dart|postscript|rtf|tar|toml|vnd\.dart|vnd\.ms-fontobject|vnd\.ms-opentype|wasm|x-httpd-php|x-javascript|x-ns-proxy-autoconfig|x-sh|x-tar|x-virtualbox-hdd|x-virtualbox-ova|x-virtualbox-ovf|x-virtualbox-vbox|x-virtualbox-vdi|x-virtualbox-vhd|x-virtualbox-vmdk|x-www-form-urlencoded)|font\/(?:otf|ttf)|image\/(?:bmp|vnd\.adobe\.photoshop|vnd\.microsoft\.icon|vnd\.ms-dds|x-icon|x-ms-bmp)|message\/rfc822|model\/gltf-binary|x-shader\/x-fragment|x-shader\/x-vertex|[^;\s]+?\+(?:json|text|xml|yaml))(?:[;\s]|$)/i,ze={br:".br",zstd:".zst",gzip:".gz"},vs=Object.keys(ze),ws=()=>{const[e,s]=Lt.node.split(".").map(t=>parseInt(t));return e>=23||e===22&&s>=7||e===20&&s>=18},Rs=ws(),rt=e=>Rs?Mt.toWeb(e):new ReadableStream({start(t){e.on("data",r=>{t.enqueue(r)}),e.on("error",r=>{t.error(r)}),e.on("end",()=>{t.close()})},cancel(){e.destroy()}}),Ye=e=>{let s;try{s=At(e)}catch{}return s},xt=(e={root:""})=>{const s=e.root||"",t=e.path;return s!==""&&!Nt(s)&&console.error(`serveStatic: root path '${s}' is not found, are you sure it's correct?`),async(r,n)=>{var _,h,b,T;if(r.finalized)return n();let a;if(t)a=t;else try{if(a=decodeURIComponent(r.req.path),/(?:^|[\/\\])\.\.(?:$|[\/\\])/.test(a))throw new Error}catch{return await((_=e.onNotFound)==null?void 0:_.call(e,r.req.path,r)),n()}let o=Qe(s,!t&&e.rewriteRequestPath?e.rewriteRequestPath(a,r):a),i=Ye(o);if(i&&i.isDirectory()){const y=e.index??"index.html";o=Qe(o,y),i=Ye(o)}if(!i)return await((h=e.onNotFound)==null?void 0:h.call(e,o,r)),n();const c=Es(o);if(r.header("Content-Type",c||"application/octet-stream"),e.precompressed&&(!c||ys.test(c))){const y=new Set((b=r.req.header("Accept-Encoding"))==null?void 0:b.split(",").map(w=>w.trim()));for(const w of vs){if(!y.has(w))continue;const S=Ye(o+ze[w]);if(S){r.header("Content-Encoding",w),r.header("Vary","Accept-Encoding",{append:!0}),i=S,o=o+ze[w];break}}}let d;const l=i.size,m=r.req.header("range")||"";if(r.req.method=="HEAD"||r.req.method=="OPTIONS")r.header("Content-Length",l.toString()),r.status(200),d=r.body(null);else if(!m)r.header("Content-Length",l.toString()),d=r.body(rt(Ze(o)),200);else{r.header("Accept-Ranges","bytes"),r.header("Date",i.birthtime.toUTCString());const y=m.replace(/bytes=/,"").split("-",2),w=parseInt(y[0],10)||0;let S=parseInt(y[1],10)||l-1;l<S-w+1&&(S=l-1);const F=S-w+1,C=Ze(o,{start:w,end:S});r.header("Content-Length",F.toString()),r.header("Content-Range",`bytes ${w}-${S}/${i.size}`),d=r.body(rt(C),206)}return await((T=e.onFound)==null?void 0:T.call(e,o,r)),d}};const p=new Dt;p.use("*",fs({origin:"*",allowMethods:["GET","POST","PUT","DELETE","PATCH","OPTIONS"],allowHeaders:["Content-Type","Authorization","X-Session-ID"],exposeHeaders:["Content-Length","X-Session-ID"],credentials:!1,maxAge:600}));p.get("/",e=>e.redirect("/dashboard"));p.use("*",async(e,s)=>{await s(),e.res.headers.set("Cache-Control","no-cache, no-store, must-revalidate, max-age=0"),e.res.headers.set("Pragma","no-cache"),e.res.headers.set("Expires","0")});p.get("/static/:filename",xt({root:"./public"}));p.use("/static/*",xt({root:"./public"}));function Ts(){return Math.random().toString(36).substring(2)+Date.now().toString(36)}function $e(){const e=new Date;return new Date(e.getTime()+540*60*1e3).toISOString().slice(0,19).replace("T"," ")}async function Oe(e,s,t,r,n,a,o,i,c,d,l,m,_,h,b=""){try{await e.prepare(`
      INSERT INTO contract_history (
        contract_id, motorcycle_id, customer_id, contract_number, contract_type,
        action_type, old_status, new_status, start_date, end_date,
        monthly_fee, deposit, special_terms, action_reason
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(s,t,r,n,a,o,i,c,d,l,m,_,h,b).run(),console.log(`📝 Contract history recorded: ${n} - ${o}`)}catch(T){console.error("❌ Failed to record contract history:",T)}}async function Ss(e,s){const t=Ts(),r=new Date(Date.now()+720*60*60*1e3).toISOString();return await e.prepare("INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, ?)").bind(t,s,r).run(),t}async function Te(e,s){return s?await e.prepare(`
    SELECT s.*, u.username, u.name, u.role 
    FROM sessions s 
    JOIN users u ON s.user_id = u.id 
    WHERE s.id = ? AND s.expires_at > datetime('now')
  `).bind(s).first():null}async function f(e,s){const t=e.req.header("X-Session-ID")||e.req.query("session");if(!t)return e.json({error:"인증이 필요합니다"},401);try{const n=e.env.DB||e.env.db;if(n){const a=await n.prepare(`
        SELECT * FROM sessions 
        WHERE id = ? AND expires_at > datetime('now')
      `).bind(t).first();if(a){const o=new Date(Date.now()+2592e6).toISOString();await n.prepare(`
          UPDATE sessions 
          SET expires_at = ? 
          WHERE id = ?
        `).bind(o,t).run(),e.set("user",{id:a.user_id,username:a.username,name:a.name,role:a.role}),await s();return}}}catch(n){console.log("DB session check failed, fallback to memory:",n)}const r=re.get(t);if(!r||r.expiresAt<Date.now())return re.delete(t),e.json({error:"세션이 만료되었습니다"},401);r.expiresAt=Date.now()+720*60*60*1e3,re.set(t,r),e.set("user",r.user),await s()}async function Ds(e,s){const t=e.req.header("X-Session-ID")||e.req.query("session"),r=e.env.DB||e.env.db,n=await Te(r,t);if(!n)return e.json({error:"인증이 필요합니다"},401);if(n.role!=="super_admin")return e.json({error:"슈퍼관리자 권한이 필요합니다"},403);e.set("user",n),await s()}const re=new Map;p.post("/api/auth/login",async e=>{const s=await e.req.json(),t=(s.username||"").trim(),r=(s.password||"").trim();console.log("🔑 로그인 시도:",{username:t,passwordLength:r.length});const a=[{id:1,username:"sangchun11",password:"a2636991",name:"상춘",role:"superadmin"},{id:2,username:"admin",password:"admin123",name:"관리자",role:"admin"}].find(o=>o.username.toLowerCase()===t.toLowerCase()&&o.password===r);if(a){const o=Math.random().toString(36).substring(2)+Date.now().toString(36);let i=!1,c=null;try{const d=e.env.DB||e.env.db;if(console.log("🔍 DB 객체 존재:",!!d),console.log("🔍 c.env.DB:",!!e.env.DB,"c.env.db:",!!e.env.db),d){const l=new Date(Date.now()+2592e6).toISOString();console.log("🔍 세션 저장 시도:",{sessionId:o,username:a.username,expiresAt:l});const m=await d.prepare(`
          INSERT INTO sessions (id, user_id, username, name, role, expires_at)
          VALUES (?, ?, ?, ?, ?, ?)
        `).bind(o,a.id,a.username,a.name,a.role,l).run();if(console.log("✅ 세션 저장 완료 (D1):",{sessionId:o,success:m.success}),!m.success)throw new Error("D1 세션 저장 실패: result.success = false");i=!0}else console.error("❌ DB 객체가 없습니다! D1 바인딩 확인 필요"),c="DB 객체가 없습니다"}catch(d){console.error("❌ 세션 저장 실패:",d),console.error("❌ 에러 상세:",JSON.stringify(d,null,2)),c=d.message}return re.set(o,{user:a,expiresAt:Date.now()+720*60*60*1e3}),e.json({success:!0,sessionId:o,user:{id:a.id,username:a.username,name:a.name,role:a.role},debug:{db_save_success:i,db_error:c}})}try{const o=e.env.DB||e.env.db;if(o){const i=await o.prepare("SELECT * FROM users WHERE LOWER(username) = LOWER(?) AND password = ?").bind(t,r).first();if(i){const c=await Ss(o,i.id);return e.json({success:!0,sessionId:c,user:{id:i.id,username:i.username,name:i.name,role:i.role}})}}}catch{console.log("DB not available, using hardcoded admin account")}return e.json({error:"아이디 또는 비밀번호가 잘못되었습니다"},401)});p.post("/api/auth/logout",async e=>{const s=e.req.header("X-Session-ID");return s&&re.delete(s),e.json({success:!0})});p.get("/api/debug/db-test",async e=>{try{const s=e.env.DB||e.env.db;if(!s)return e.json({error:"DB is undefined",env_keys:Object.keys(e.env),has_DB:!!e.env.DB,has_db:!!e.env.db,message:"D1 바인딩이 없습니다"});const t=await s.prepare("SELECT COUNT(*) as count FROM sessions").first();return e.json({success:!0,db_exists:!0,sessions_count:(t==null?void 0:t.count)||0,env_keys:Object.keys(e.env),message:"DB 연결 성공"})}catch(s){return e.json({error:s.message,stack:s.stack,env_keys:Object.keys(e.env)})}});p.get("/api/auth/check",async e=>{const s=e.req.header("X-Session-ID")||e.req.query("session");if(!s)return e.json({authenticated:!1});try{const r=e.env.DB||e.env.db;if(r){const n=await r.prepare(`
        SELECT * FROM sessions 
        WHERE id = ? AND expires_at > datetime('now')
      `).bind(s).first();if(n){const a=new Date(Date.now()+2592e6).toISOString();return await r.prepare(`
          UPDATE sessions 
          SET expires_at = ? 
          WHERE id = ?
        `).bind(a,s).run(),e.json({authenticated:!0,user:{id:n.user_id,username:n.username,name:n.name,role:n.role}})}}}catch(r){console.log("DB session check failed, fallback to memory:",r)}const t=re.get(s);return t?t.expiresAt<Date.now()?(re.delete(s),e.json({authenticated:!1})):(t.expiresAt=Date.now()+720*60*60*1e3,re.set(s,t),e.json({authenticated:!0,user:{id:t.user.id,username:t.user.username,name:t.user.name,role:t.user.role}})):e.json({authenticated:!1})});p.get("/api/admin/users",async e=>{const s=e.env.DB||e.env.db,t=e.req.header("X-Session-ID"),r=await Te(s,t),n=r==null?void 0:r.role;if(!r||n!=="super_admin"&&n!=="superadmin")return e.json({error:"권한이 없습니다"},403);const a=await s.prepare(`
    SELECT 
      u.id,
      u.username,
      u.name,
      u.email,
      u.phone,
      u.role,
      u.status,
      u.created_at,
      (SELECT COUNT(*) FROM sessions WHERE user_id = u.id) as is_logged_in
    FROM users u
    ORDER BY u.username ASC
  `).all();return e.json({success:!0,admins:a.results})});p.post("/api/admin/users/:id/status",async e=>{const s=e.env.DB||e.env.db,t=e.req.header("X-Session-ID"),r=await Te(s,t),n=r==null?void 0:r.role;if(!r||n!=="super_admin"&&n!=="superadmin")return e.json({error:"권한이 없습니다"},403);const a=e.req.param("id"),{status:o}=await e.req.json();if(r.user_id===parseInt(a))return e.json({error:"자기 자신의 상태는 변경할 수 없습니다"},400);const i=await s.prepare("SELECT role FROM users WHERE id = ?").bind(a).first();return i&&i.role==="super_admin"?e.json({error:"슈퍼관리자는 정지할 수 없습니다"},400):(await s.prepare("UPDATE users SET status = ? WHERE id = ?").bind(o,a).run(),o==="inactive"&&await s.prepare("DELETE FROM sessions WHERE user_id = ?").bind(a).run(),e.json({success:!0}))});p.patch("/api/admin/users/:username/status",async e=>{const s=e.env.DB||e.env.db,t=e.req.header("X-Session-ID"),r=await Te(s,t),n=r==null?void 0:r.role;if(!r||n!=="super_admin"&&n!=="superadmin")return e.json({error:"권한이 없습니다"},403);const a=e.req.param("username"),{status:o}=await e.req.json();if(!["active","inactive"].includes(o))return e.json({error:"유효하지 않은 상태값입니다"},400);if(r.username===a)return e.json({error:"자기 자신의 상태는 변경할 수 없습니다"},400);const i=await s.prepare("SELECT id, role FROM users WHERE username = ?").bind(a).first();return i?i.role==="super_admin"?e.json({error:"슈퍼관리자는 정지할 수 없습니다"},400):(await s.prepare("UPDATE users SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE username = ?").bind(o,a).run(),o==="inactive"&&await s.prepare("DELETE FROM sessions WHERE user_id = ?").bind(i.id).run(),e.json({success:!0,message:o==="active"?"사용자가 활성화되었습니다":"사용자가 비활성화되었습니다"})):e.json({error:"사용자를 찾을 수 없습니다"},404)});p.post("/api/auth/find-username",async e=>{try{const s=e.env.DB||e.env.db,{name:t,phone:r}=await e.req.json();console.log("🔍 아이디 찾기 요청:",{name:t,phone:r});const n=await s.prepare("SELECT username, created_at FROM users WHERE name = ? AND phone = ?").bind(t,r).first();return console.log("🔍 조회 결과:",n),n?e.json({success:!0,username:n.username,created_at:n.created_at}):e.json({error:"일치하는 사용자를 찾을 수 없습니다"},404)}catch(s){return console.error("❌ 아이디 찾기 에러:",s),e.json({error:"서버 오류가 발생했습니다: "+s.message},500)}});p.post("/api/auth/request-reset",async e=>{try{const s=e.env.DB||e.env.db,{username:t,name:r,phone:n}=await e.req.json();console.log("🔐 비밀번호 재설정 요청:",{username:t,name:r,phone:n});const a=await s.prepare("SELECT * FROM users WHERE username = ? AND name = ? AND phone = ?").bind(t,r,n).first();if(!a)return e.json({error:"일치하는 사용자를 찾을 수 없습니다"},404);console.log("✅ 사용자 확인:",{id:a.id,email:a.email});const o=Math.floor(1e5+Math.random()*9e5).toString(),i=new Date(Date.now()+1800*1e3).toISOString();await s.prepare("INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (?, ?, ?)").bind(a.id,o,i).run();const c=a.email;if(c)try{console.log("📧 이메일 발송 시도:",c);const d=`
          <html>
            <head>
              <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { background: #f7fafc; padding: 30px; border: 1px solid #e2e8f0; }
                .token { font-size: 32px; font-weight: bold; color: #667eea; letter-spacing: 8px; text-align: center; padding: 20px; background: white; border-radius: 8px; margin: 20px 0; }
                .info { background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; }
                .footer { text-align: center; color: #718096; padding: 20px; font-size: 12px; }
              </style>
            </head>
            <body>
              <div class="container">
                <div class="header">
                  <h1>🔐 비밀번호 재설정</h1>
                  <p>Z-BIKE 오토바이 리스/렌트 시스템</p>
                </div>
                <div class="content">
                  <p>안녕하세요, <strong>${a.name}</strong>님!</p>
                  <p>비밀번호 재설정을 위한 인증번호가 발급되었습니다.</p>
                  
                  <div class="token">${o}</div>
                  
                  <div class="info">
                    <p><strong>⏰ 유효시간: 30분</strong></p>
                    <p>인증번호는 30분 동안만 유효합니다. 시간 내에 입력해주세요.</p>
                  </div>
                  
                  <p>본인이 요청하지 않은 경우, 이 메일을 무시하셔도 됩니다.</p>
                </div>
                <div class="footer">
                  <p>© 2026 Z-BIKE. All rights reserved.</p>
                  <p>이 메일은 발신 전용입니다.</p>
                </div>
              </div>
            </body>
          </html>
        `,l=e.env.RESEND_API_KEY||"";if(l){const m=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${l}`,"Content-Type":"application/json"},body:JSON.stringify({from:"Z-BIKE <noreply@zbike.com>",to:[c],subject:"[Z-BIKE] 비밀번호 재설정 인증번호",html:d})}),_=await m.json();if(console.log("📧 이메일 발송 결과:",_),m.ok)return e.json({success:!0,message:`인증번호가 ${c}로 발송되었습니다. 이메일을 확인해주세요.`,email:c.replace(/(.{2})(.*)(@.*)/,"$1***$3")})}return console.log("⚠️ 이메일 발송 실패 또는 API 키 없음. 토큰을 화면에 표시합니다."),e.json({success:!0,token:o,message:"인증번호가 생성되었습니다. (이메일 발송 기능 미설정)",email:c})}catch(d){return console.error("❌ 이메일 발송 에러:",d),e.json({success:!0,token:o,message:"인증번호가 생성되었습니다. (이메일 발송 실패)",email:c})}else return e.json({success:!0,token:o,message:"인증번호가 생성되었습니다. (이메일 미등록)"})}catch(s){return console.error("❌ 비밀번호 재설정 요청 에러:",s),e.json({error:"서버 오류가 발생했습니다: "+s.message},500)}});p.post("/api/auth/reset-password",async e=>{const s=e.env.DB||e.env.db,{token:t,new_password:r}=await e.req.json(),n=await s.prepare(`
    SELECT * FROM password_reset_tokens 
    WHERE token = ? AND used = 0 AND expires_at > datetime('now')
  `).bind(t).first();return n?(await s.prepare("UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(r,n.user_id).run(),await s.prepare("UPDATE password_reset_tokens SET used = 1 WHERE id = ?").bind(n.id).run(),e.json({success:!0,message:"비밀번호가 재설정되었습니다"})):e.json({error:"유효하지 않거나 만료된 인증번호입니다"},400)});p.get("/api/motorcycles",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.query("status");let r=`
    SELECT 
      m.*,
      c.id as contract_id,
      c.contract_type,
      c.status as contract_status,
      cu.name as customer_name,
      c.start_date,
      c.end_date
    FROM motorcycles m
    LEFT JOIN contracts c ON m.id = c.motorcycle_id 
      AND c.status = 'active'
      AND date(c.end_date) >= date('now')
    LEFT JOIN customers cu ON c.customer_id = cu.id
  `;t&&(r+=` WHERE m.status = '${t}'`),r+=" ORDER BY m.created_at DESC";const n=await s.prepare(r).all();return e.json(n.results)});p.get("/api/public/motorcycles",async e=>{var t;const s=e.env.DB||e.env.db;try{const n=((t=(await s.prepare(`
      SELECT 
        id,
        plate_number,
        chassis_number,
        vehicle_name,
        status,
        insurance_company,
        driving_range,
        insurance_start_date,
        insurance_end_date
      FROM motorcycles
      ORDER BY plate_number
    `).all()).results)==null?void 0:t.filter(a=>a.status!=="scrapped"))||[];return e.json(n)}catch(r){return console.error("Public motorcycles API error:",r),e.json({error:"Failed to load motorcycles",details:r.message},500)}});p.get("/api/public/customers",async e=>{const s=e.env.DB||e.env.db;try{const t=await s.prepare(`
      SELECT 
        id,
        name,
        resident_number,
        phone,
        postcode,
        address,
        detail_address
      FROM customers
      ORDER BY created_at DESC
    `).all();return e.json(t.results||[])}catch(t){return console.error("Public customers API error:",t),e.json({error:"Failed to load customers",details:t.message},500)}});p.get("/api/public/motorcycles/search",async e=>{const s=e.env.DB||e.env.db,t=e.req.query("plate_number");if(!t)return e.json({error:"번호판을 입력해주세요"},400);const r=await s.prepare(`
    SELECT 
      id,
      plate_number,
      vehicle_name,
      model_year
    FROM motorcycles 
    WHERE plate_number = ? AND status = 'available' AND deleted_at IS NULL
  `).bind(t).first();return r?e.json(r):e.json({error:"해당 번호판의 오토바이를 찾을 수 없습니다"},404)});p.get("/api/motorcycles/:id",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await s.prepare("SELECT * FROM motorcycles WHERE id = ?").bind(t).first();return r?e.json(r):e.json({error:"오토바이를 찾을 수 없습니다"},404)});p.post("/api/motorcycles",f,async e=>{const s=e.env.DB||e.env.db;if(!s)return e.json({error:"Database not available"},500);try{const t=await e.req.json(),r=await s.prepare(`
      INSERT INTO motorcycles (
        plate_number, vehicle_name, chassis_number, mileage, model_year,
        insurance_company, insurance_start_date, insurance_end_date,
        inspection_start_date, inspection_end_date,
        driving_range, owner_name, insurance_fee, vehicle_price, daily_rental_fee, usage_notes, status,
        certificate_photo
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(t.plate_number,t.vehicle_name,t.chassis_number,t.mileage,t.model_year,t.insurance_company,t.insurance_start_date,t.insurance_end_date,t.inspection_start_date||null,t.inspection_end_date||null,t.driving_range,t.owner_name,t.insurance_fee,t.vehicle_price,t.daily_rental_fee||0,t.usage_notes||"",t.status||"available",t.certificate_photo||null).run();return e.json({id:r.meta.last_row_id,...t},201)}catch(t){return console.error("오토바이 등록 오류:",t),e.json({error:"오토바이 등록 실패",details:t.message},500)}});p.put("/api/motorcycles/:id",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await e.req.json();try{const n=await s.prepare("SELECT * FROM motorcycles WHERE id = ?").bind(t).first();if(!n)return e.json({error:"오토바이를 찾을 수 없습니다"},404);const a={plate_number:r.plate_number!==void 0?r.plate_number:n.plate_number,vehicle_name:r.vehicle_name!==void 0?r.vehicle_name:n.vehicle_name,chassis_number:r.chassis_number!==void 0?r.chassis_number:n.chassis_number,mileage:r.mileage!==void 0?r.mileage:n.mileage,model_year:r.model_year!==void 0?r.model_year:n.model_year,insurance_company:r.insurance_company!==void 0?r.insurance_company:n.insurance_company,insurance_start_date:r.insurance_start_date!==void 0?r.insurance_start_date:n.insurance_start_date,insurance_end_date:r.insurance_end_date!==void 0?r.insurance_end_date:n.insurance_end_date,inspection_start_date:r.inspection_start_date!==void 0?r.inspection_start_date:n.inspection_start_date,inspection_end_date:r.inspection_end_date!==void 0?r.inspection_end_date:n.inspection_end_date,driving_range:r.driving_range!==void 0?r.driving_range:n.driving_range,owner_name:r.owner_name!==void 0?r.owner_name:n.owner_name,insurance_fee:r.insurance_fee!==void 0?r.insurance_fee:n.insurance_fee,vehicle_price:r.vehicle_price!==void 0?r.vehicle_price:n.vehicle_price,daily_rental_fee:r.daily_rental_fee!==void 0?r.daily_rental_fee:n.daily_rental_fee||0,usage_notes:r.usage_notes!==void 0?r.usage_notes:n.usage_notes||"",status:r.status!==void 0?r.status:n.status,certificate_photo:r.certificate_photo!==void 0?r.certificate_photo:n.certificate_photo,monthly_fee:r.monthly_fee!==void 0?r.monthly_fee:n.monthly_fee||0,contract_type_text:r.contract_type_text!==void 0?r.contract_type_text:n.contract_type_text||"",deposit:r.deposit!==void 0?r.deposit:n.deposit||0,contract_start_date:r.contract_start_date!==void 0?r.contract_start_date:n.contract_start_date||"",contract_end_date:r.contract_end_date!==void 0?r.contract_end_date:n.contract_end_date||""},o=e.get("user"),i=(o==null?void 0:o.id)||null,c=[{key:"insurance_company",name:"보험사"},{key:"insurance_start_date",name:"보험시작일"},{key:"insurance_end_date",name:"보험종료일"},{key:"driving_range",name:"운전범위"},{key:"inspection_start_date",name:"검사시작일"},{key:"inspection_end_date",name:"검사종료일"},{key:"status",name:"상태"},{key:"mileage",name:"키로수"},{key:"insurance_fee",name:"보험료"},{key:"daily_rental_fee",name:"일대여료"}];for(const d of c){const l=String(n[d.key]||""),m=String(a[d.key]||"");l!==m&&await s.prepare(`
          INSERT INTO motorcycle_history 
          (motorcycle_id, change_type, field_name, old_value, new_value, changed_by, notes)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `).bind(t,"update",d.name,l,m,i,`${d.name} 변경: ${l} → ${m}`).run()}return await s.prepare(`
      UPDATE motorcycles SET
        plate_number = ?, vehicle_name = ?, chassis_number = ?, mileage = ?,
        model_year = ?, insurance_company = ?, insurance_start_date = ?,
        insurance_end_date = ?, inspection_start_date = ?, inspection_end_date = ?,
        driving_range = ?, owner_name = ?,
        insurance_fee = ?, vehicle_price = ?, daily_rental_fee = ?, usage_notes = ?, status = ?,
        certificate_photo = ?,
        monthly_fee = ?, contract_type_text = ?, deposit = ?,
        contract_start_date = ?, contract_end_date = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(a.plate_number,a.vehicle_name,a.chassis_number,a.mileage,a.model_year,a.insurance_company,a.insurance_start_date,a.insurance_end_date,a.inspection_start_date,a.inspection_end_date,a.driving_range,a.owner_name,a.insurance_fee,a.vehicle_price,a.daily_rental_fee,a.usage_notes,a.status,a.certificate_photo,a.monthly_fee,a.contract_type_text,a.deposit,a.contract_start_date,a.contract_end_date,t).run(),e.json({success:!0,id:t,...a})}catch(n){return console.error("오토바이 수정 오류:",n),e.json({error:"수정 중 오류가 발생했습니다: "+n.message},500)}});p.get("/api/motorcycles/:id/history",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id");try{const{results:r}=await s.prepare(`
      SELECT 
        h.id,
        h.change_type,
        h.field_name,
        h.old_value,
        h.new_value,
        h.change_date,
        h.notes,
        u.name as changed_by_name
      FROM motorcycle_history h
      LEFT JOIN users u ON h.changed_by = u.id
      WHERE h.motorcycle_id = ?
      ORDER BY h.change_date DESC
    `).bind(t).all();return e.json({history:r})}catch(r){return console.error("오토바이 이력 조회 오류:",r),e.json({error:"이력 조회에 실패했습니다",details:r.message},500)}});p.delete("/api/motorcycles/:id",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id");try{return await s.prepare("DELETE FROM contract_history WHERE motorcycle_id = ?").bind(t).run(),await s.prepare("DELETE FROM contracts WHERE motorcycle_id = ?").bind(t).run(),await s.prepare("DELETE FROM business_contracts WHERE motorcycle_id = ?").bind(t).run(),await s.prepare("DELETE FROM motorcycles WHERE id = ?").bind(t).run(),e.json({message:"삭제되었습니다"})}catch(r){return console.error("오토바이 삭제 실패:",r),e.json({error:"삭제에 실패했습니다: "+r.message},500)}});p.patch("/api/motorcycles/:id/status",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),{status:r,usage_notes:n}=await e.req.json();return["available","rented","maintenance","scrapped"].includes(r)?(r==="scrapped"&&n?await s.prepare(`
      UPDATE motorcycles 
      SET status = ?, usage_notes = ?, updated_at = CURRENT_TIMESTAMP 
      WHERE id = ?
    `).bind(r,n,t).run():r==="available"?(console.log(`🔄 Contract termination for motorcycle #${t} - clearing contract info only (keeping basic and insurance info)`),await s.prepare(`
      UPDATE motorcycles 
      SET status = ?,
          monthly_fee = NULL,
          contract_type_text = NULL,
          deposit = NULL,
          contract_start_date = NULL,
          contract_end_date = NULL,
          owner_name = '',
          updated_at = CURRENT_TIMESTAMP 
      WHERE id = ?
    `).bind(r,t).run(),console.log(`✅ Contract info cleared for motorcycle #${t} (basic info and insurance info preserved)`)):await s.prepare(`
      UPDATE motorcycles 
      SET status = ?, updated_at = CURRENT_TIMESTAMP 
      WHERE id = ?
    `).bind(r,t).run(),e.json({message:r==="scrapped"?"폐지 처리되었습니다":"상태가 변경되었습니다",status:r})):e.json({error:"유효하지 않은 상태입니다"},400)});p.post("/api/motorcycles/:id/scrap",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),{usage_notes:r}=await e.req.json();console.log(`🗑️ Scrapping motorcycle #${t}`);const n=await s.prepare("SELECT * FROM motorcycles WHERE id = ?").bind(t).first();return n?(console.log(`📋 Original motorcycle: ${n.vehicle_name} (${n.chassis_number})`),await s.prepare(`
    UPDATE motorcycles 
    SET 
      plate_number = '',
      mileage = 0,
      insurance_company = '',
      insurance_start_date = '',
      insurance_end_date = '',
      driving_range = '',
      owner_name = '',
      insurance_fee = 0,
      vehicle_price = 0,
      daily_rental_fee = 0,
      monthly_fee = NULL,
      contract_type_text = NULL,
      deposit = NULL,
      contract_start_date = NULL,
      contract_end_date = NULL,
      status = 'scrapped',
      usage_notes = ?,
      inspection_start_date = NULL,
      inspection_end_date = NULL,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).bind(r,t).run(),console.log(`✅ Motorcycle #${t} scrapped. Only vehicle_name, chassis_number, model_year preserved. All other data cleared.`),console.log(`📝 Scrap reason: ${r}`),e.json({message:"폐지 처리되었습니다. 계약 이력은 보존되었습니다.",preserved:{vehicle_name:n.vehicle_name,chassis_number:n.chassis_number,model_year:n.model_year}})):e.json({error:"오토바이를 찾을 수 없습니다"},404)});p.get("/api/motorcycles/:id/contracts",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await s.prepare(`
    SELECT 
      c.*,
      cu.name as customer_name, cu.phone as customer_phone,
      cu.resident_number, cu.address, cu.license_type
    FROM contracts c
    JOIN customers cu ON c.customer_id = cu.id
    WHERE c.motorcycle_id = ?
    ORDER BY c.created_at DESC
  `).bind(t).all();return e.json(r.results)});p.get("/api/customers",f,async e=>{const t=await(e.env.DB||e.env.db).prepare(`
    SELECT 
      c.*,
      ct.contract_type as active_contract_type
    FROM customers c
    LEFT JOIN contracts ct ON c.id = ct.customer_id AND ct.status = 'active'
    ORDER BY c.created_at DESC
  `).all();return e.json(t.results)});p.get("/api/customers/search",async e=>{const s=e.env.DB||e.env.db,t=e.req.query("resident_number");if(!t)return e.json({error:"주민등록번호를 입력해주세요"},400);const r=await s.prepare("SELECT * FROM customers WHERE resident_number = ?").bind(t).all();return e.json(r.results)});p.get("/api/customers/:id",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await s.prepare("SELECT * FROM customers WHERE id = ?").bind(t).first();return r?e.json(r):e.json({error:"고객을 찾을 수 없습니다"},404)});p.post("/api/customers",async e=>{const s=e.env.DB||e.env.db,t=await e.req.json(),r=await s.prepare(`
    INSERT INTO customers (name, resident_number, phone, postcode, address, detail_address, license_type)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).bind(t.name,t.resident_number,t.phone,t.postcode||"",t.address,t.detail_address||"",t.license_type).run();return e.json({id:r.meta.last_row_id,...t},201)});p.put("/api/customers/:id",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await e.req.json();return await s.prepare(`
    UPDATE customers SET
      name = ?, resident_number = ?, phone = ?, postcode = ?, address = ?, detail_address = ?, license_type = ?,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).bind(r.name,r.resident_number,r.phone,r.postcode||"",r.address,r.detail_address||"",r.license_type,t).run(),e.json({id:t,...r})});p.delete("/api/customers/:id",f,async e=>{var n,a,o,i,c,d,l,m,_,h,b,T,y,w,S,F;const s=e.env.DB||e.env.db,t=e.req.param("id");if(e.get("user").role!=="super_admin")return e.json({error:"슈퍼관리자만 계약자를 삭제할 수 있습니다"},403);try{console.log("계약자 삭제 시작 (슈퍼관리자):",t);const C=await s.prepare("SELECT id, name, resident_number FROM customers WHERE id = ?").bind(t).first();if(!C)return e.json({error:"계약자를 찾을 수 없습니다"},404);console.log("📋 삭제할 계약자:",C.name,"/",C.resident_number);const q=(await s.prepare("SELECT id FROM contracts WHERE customer_id = ?").bind(t).all()).results.map(D=>D.id);console.log("📝 삭제할 계약서 ID:",q),console.log("🔄 Batch 삭제 시작...");const H=[s.prepare("PRAGMA foreign_keys = OFF"),s.prepare("DROP TRIGGER IF EXISTS prevent_history_update"),s.prepare("DROP TRIGGER IF EXISTS prevent_history_delete")];if(q.length>0){const D=q.join(",");H.push(s.prepare(`UPDATE contract_history SET contract_id = NULL WHERE contract_id IN (${D})`)),console.log("📝 계약 이력의 참조를 해제합니다 (contract_id를 NULL로 설정)")}H.push(s.prepare("DELETE FROM loan_contracts WHERE borrower_resident_number = ?").bind(C.resident_number)),H.push(s.prepare("DELETE FROM contracts WHERE customer_id = ?").bind(t)),H.push(s.prepare("DELETE FROM customers WHERE id = ?").bind(t)),H.push(s.prepare(`CREATE TRIGGER prevent_history_update
BEFORE UPDATE ON contract_history
BEGIN
  SELECT RAISE(ABORT, '❌ 계약 이력은 수정할 수 없습니다. 이력은 영구적으로 보호됩니다.');
END`)),H.push(s.prepare(`CREATE TRIGGER prevent_history_delete
BEFORE DELETE ON contract_history
BEGIN
  SELECT RAISE(ABORT, '❌ 계약 이력은 삭제할 수 없습니다. 이력은 영구적으로 보호됩니다.');
END`)),H.push(s.prepare("PRAGMA foreign_keys = ON"));const A=await s.batch(H),x=q.length>0?3:-1,X=x+1,P=X+1,j=P+1;return console.log("✅ Batch 삭제 완료"),console.log("📊 삭제 결과:",{history_updated:x>0&&((a=(n=A[x])==null?void 0:n.meta)==null?void 0:a.changes)||0,loan_contracts:((i=(o=A[X])==null?void 0:o.meta)==null?void 0:i.changes)||0,contracts:((d=(c=A[P])==null?void 0:c.meta)==null?void 0:d.changes)||0,customer:((m=(l=A[j])==null?void 0:l.meta)==null?void 0:m.changes)||0}),e.json({message:"삭제되었습니다. 계약 이력은 보존됩니다.",deleted:{contracts:((h=(_=A[P])==null?void 0:_.meta)==null?void 0:h.changes)||0,loan_contracts:((T=(b=A[X])==null?void 0:b.meta)==null?void 0:T.changes)||0,customer:((w=(y=A[j])==null?void 0:y.meta)==null?void 0:w.changes)||0},preserved:{contract_history:`이력 보호 정책에 따라 보존됨 (${x>0&&((F=(S=A[x])==null?void 0:S.meta)==null?void 0:F.changes)||0}건의 이력 참조 해제)`}})}catch(C){return console.error("❌ 계약자 삭제 최종 실패:",C),console.error("❌ 에러 상세:",C.message),e.json({error:"삭제에 실패했습니다: "+C.message},500)}});p.get("/api/companies",f,async e=>{const t=await(e.env.DB||e.env.db).prepare(`
    SELECT * FROM companies ORDER BY created_at DESC
  `).all();return e.json(t.results)});p.get("/api/companies/:id",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await s.prepare("SELECT * FROM companies WHERE id = ?").bind(t).first();return r?e.json(r):e.json({error:"업체를 찾을 수 없습니다"},404)});p.post("/api/companies",f,async e=>{const s=e.env.DB||e.env.db,t=await e.req.json(),r=await s.prepare(`
    INSERT INTO companies (name, business_number, representative, representative_resident_number, phone, postcode, address, detail_address, signature_data, id_card_photo, terms_agreed)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(t.name,t.business_number,t.representative,t.representative_resident_number||"",t.phone,t.postcode||"",t.address,t.detail_address||"",t.signature_data||"",t.id_card_photo||"",t.terms_agreed?1:0).run();return e.json({id:r.meta.last_row_id,...t},201)});p.put("/api/companies/:id",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await e.req.json();return await s.prepare(`
    UPDATE companies SET
      name = ?, business_number = ?, representative = ?, representative_resident_number = ?, phone = ?, postcode = ?, address = ?, detail_address = ?,
      signature_data = ?, id_card_photo = ?,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).bind(r.name,r.business_number,r.representative,r.representative_resident_number||"",r.phone,r.postcode||"",r.address,r.detail_address||"",r.signature_data||"",r.id_card_photo||"",t).run(),e.json({id:t,...r})});p.delete("/api/companies/:id",Ds,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await s.prepare(`
    SELECT name, business_number FROM companies WHERE id = ?
  `).bind(t).first();return r?(await s.prepare(`
    DELETE FROM business_contracts 
    WHERE company_name = ? AND business_number = ?
  `).bind(r.name,r.business_number).run(),await s.prepare(`
    DELETE FROM companies WHERE id = ?
  `).bind(t).run(),e.json({message:"업체 및 관련 계약서가 완전히 삭제되었습니다",id:t,company_name:r.name})):e.json({error:"업체를 찾을 수 없습니다"},404)});p.get("/api/dashboard/stats",f,async e=>{const s=e.env.DB||e.env.db;if(!s)return e.json({motorcycles:{total:0,available:0,rented:0,maintenance:0},customers:0,contracts:{active:0,monthly_revenue:0,total_deposits:0,active_business:0,active_temp:0,active_loans:0,total_loan_amount:0}});try{const t=await s.prepare(`
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available,
        SUM(CASE WHEN status = 'maintenance' THEN 1 ELSE 0 END) as maintenance,
        SUM(CASE WHEN status = 'scrapped' THEN 1 ELSE 0 END) as scrapped
      FROM motorcycles
    `).first(),r=await s.prepare(`
      SELECT COUNT(DISTINCT customer_id) as count 
      FROM contracts
    `).first(),n=await s.prepare(`
      SELECT 
        COUNT(*) as active_contracts,
        SUM(CAST(monthly_fee as INTEGER)) as total_monthly_revenue,
        SUM(CAST(deposit as INTEGER)) as total_deposits
      FROM contracts
      WHERE status = 'active'
    `).first(),a=await s.prepare(`
      SELECT COUNT(*) as active_business_contracts
      FROM business_contracts
      WHERE status = 'active'
    `).first(),o=((n==null?void 0:n.active_contracts)||0)+((a==null?void 0:a.active_business_contracts)||0),i=await s.prepare(`
      SELECT 
        COUNT(*) as active_loans,
        SUM(CAST(loan_amount as INTEGER)) as total_loan_amount
      FROM loan_contracts
      WHERE status = 'active'
    `).first(),c=await s.prepare(`
      SELECT COUNT(*) as active_temp_contracts
      FROM contracts
      WHERE status = 'active' AND contract_type = 'temp_rent'
    `).first();return e.json({motorcycles:{total:t.total||0,available:t.available||0,rented:o,maintenance:(t.maintenance||0)+(t.scrapped||0)},customers:(r==null?void 0:r.count)||0,contracts:{active:o,monthly_revenue:(n==null?void 0:n.total_monthly_revenue)||0,total_deposits:(n==null?void 0:n.total_deposits)||0,active_business:(a==null?void 0:a.active_business_contracts)||0,active_temp:(c==null?void 0:c.active_temp_contracts)||0,active_loans:(i==null?void 0:i.active_loans)||0,total_loan_amount:(i==null?void 0:i.total_loan_amount)||0}})}catch(t){return console.error("통계 조회 오류:",t),e.json({error:"통계 조회 실패"},500)}});p.get("/api/contracts",async e=>{const s=e.env.DB||e.env.db,t=e.req.query("resident_number");let r=`
    SELECT 
      c.*,
      m.plate_number, m.vehicle_name,
      cu.name as customer_name, cu.phone as customer_phone
    FROM contracts c
    JOIN motorcycles m ON c.motorcycle_id = m.id
    LEFT JOIN customers cu ON c.customer_id = cu.id
    WHERE c.deleted_at IS NULL
  `;const n=[];t&&(r+=" AND cu.resident_number = ?",n.push(t)),r+=" ORDER BY c.created_at DESC";const a=s.prepare(r),o=n.length>0?await a.bind(...n).all():await a.all();return e.json(o.results)});p.get("/api/motorcycles/:id/contracts",async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await s.prepare(`
    SELECT 
      c.*,
      cu.name as customer_name, cu.resident_number, cu.phone as customer_phone,
      cu.address as customer_address, cu.license_type
    FROM contracts c
    JOIN customers cu ON c.customer_id = cu.id
    WHERE c.motorcycle_id = ?
    ORDER BY c.created_at DESC
  `).bind(t).all();return e.json(r.results)});p.get("/api/contracts/:id",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await s.prepare(`
    SELECT 
      c.*,
      m.vehicle_name, m.plate_number, m.chassis_number, m.model_year, 
      m.mileage, m.insurance_company, m.insurance_start_date, m.insurance_end_date,
      m.driving_range as motorcycle_driving_range,
      m.owner_name, m.insurance_fee, m.vehicle_price, m.daily_rental_fee,
      cu.name as customer_name, cu.resident_number, cu.phone as customer_phone,
      cu.address as customer_address, cu.license_type
    FROM contracts c
    JOIN motorcycles m ON c.motorcycle_id = m.id
    JOIN customers cu ON c.customer_id = cu.id
    WHERE c.id = ?
  `).bind(t).first();return r?e.json(r):e.json({error:"계약서를 찾을 수 없습니다"},404)});p.put("/api/contracts/:id/complete",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await s.prepare(`
    SELECT motorcycle_id, status FROM contracts WHERE id = ?
  `).bind(t).first();return r?r.status==="completed"?e.json({error:"이미 완료된 계약서입니다"},400):(await s.prepare(`
    UPDATE contracts 
    SET status = 'completed', updated_at = CURRENT_TIMESTAMP 
    WHERE id = ?
  `).bind(t).run(),await s.prepare(`
    UPDATE motorcycles 
    SET status = 'available', updated_at = CURRENT_TIMESTAMP 
    WHERE id = ?
  `).bind(r.motorcycle_id).run(),e.json({message:"계약이 완료 처리되었습니다"})):e.json({error:"계약서를 찾을 수 없습니다"},404)});p.post("/api/contracts",async e=>{const s=e.env.DB||e.env.db,t=await e.req.json();t.customer_id&&t.customer_name&&(console.log("📝 Updating customer info:",{id:t.customer_id,name:t.customer_name,postcode:t.postcode,address:t.address,detail_address:t.detail_address}),await s.prepare(`
      UPDATE customers SET 
        name = ?, 
        phone = ?,
        resident_number = ?, 
        postcode = ?,
        address = ?, 
        detail_address = ?,
        license_type = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(t.customer_name,t.customer_phone||"",t.resident_number||"",t.postcode||"",t.address||"",t.detail_address||"",t.license_type||"2종소형",t.customer_id).run(),console.log("✅ Customer info updated successfully"));const r=new Date().toISOString().slice(0,10).replace(/-/g,""),a=(await s.prepare("SELECT COUNT(*) as count FROM contracts WHERE contract_number LIKE ?").bind(`${r}-%`).first()).count+1,o=`${r}-${String(a).padStart(4,"0")}`;if(t.customer_id&&t.contract_type!=="temp_rent"){console.log("🔄 Checking for existing active contracts for customer:",t.customer_id);const _=await s.prepare(`
      SELECT id, contract_number, contract_type, motorcycle_id FROM contracts 
      WHERE customer_id = ? AND status = 'active' AND contract_type != 'temp_rent'
    `).bind(t.customer_id).all();if(_.results.length>0){console.log(`📋 Found ${_.results.length} active personal contract(s) for this customer, cancelling them...`);for(const h of _.results){const b=h;await s.prepare(`
          UPDATE contracts 
          SET status = 'cancelled', 
              end_date = ?, 
              updated_at = CURRENT_TIMESTAMP 
          WHERE id = ?
        `).bind(r,b.id).run(),await s.prepare("UPDATE motorcycles SET status = ? WHERE id = ?").bind("available",b.motorcycle_id).run(),await Oe(s,b.id,b.motorcycle_id,t.customer_id,b.contract_number,b.contract_type,"replaced","active","cancelled","",r,0,0,"",`새 계약(${o})으로 인한 자동 해지 (같은 고객의 새 계약)`),console.log(`✅ Cancelled personal contract: ${b.contract_number} (type: ${b.contract_type})`)}}}console.log("🔄 Checking for existing active contracts for motorcycle:",t.motorcycle_id);const i=await s.prepare(`
    SELECT * FROM contracts 
    WHERE motorcycle_id = ? AND status = 'active'
  `).bind(t.motorcycle_id).all();if(i.results.length>0){console.log(`📋 Found ${i.results.length} active personal contract(s), replacing them...`);for(const _ of i.results){const h=_;await s.prepare(`
        UPDATE contracts 
        SET status = 'cancelled', end_date = ?, updated_at = CURRENT_TIMESTAMP 
        WHERE id = ?
      `).bind(r,h.id).run(),await Oe(s,h.id,h.motorcycle_id,h.customer_id,h.contract_number,h.contract_type,"replaced","active","cancelled",h.start_date,r,h.monthly_fee,h.deposit,h.special_terms,`새 계약(${o})으로 인한 자동 해지`),console.log(`✅ Replaced personal contract: ${h.contract_number}`)}}const c=await s.prepare(`
    SELECT * FROM business_contracts 
    WHERE motorcycle_id = ? AND status = 'active'
  `).bind(t.motorcycle_id).all();if(c.results.length>0){console.log(`📋 Found ${c.results.length} active business contract(s), replacing them...`);for(const _ of c.results){const h=_;await s.prepare(`
        UPDATE business_contracts 
        SET status = 'cancelled', end_date = ?, updated_at = CURRENT_TIMESTAMP 
        WHERE id = ?
      `).bind(r,h.id).run(),console.log(`✅ Replaced business contract: ${h.contract_number}`)}}const d=$e(),l=await s.prepare(`
    INSERT INTO contracts (
      contract_type, motorcycle_id, customer_id, start_date, end_date,
      monthly_fee, deposit, special_terms, signature_data, id_card_photo, contract_number, status, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(t.contract_type,t.motorcycle_id,t.customer_id,t.start_date,t.end_date,t.monthly_fee,t.deposit||0,t.special_terms||"",t.signature_data||"",t.id_card_photo||"",o,"active",d,d).run(),m=l.meta.last_row_id;return await Oe(s,Number(m),t.motorcycle_id,t.customer_id,o,t.contract_type,"created",null,"active",t.start_date,t.end_date,t.monthly_fee,t.deposit||0,t.special_terms||"","새 계약 생성"),await s.prepare("UPDATE motorcycles SET status = ? WHERE id = ?").bind("rented",t.motorcycle_id).run(),e.json({id:l.meta.last_row_id,contract_number:o,...t},201)});p.post("/api/public/contracts",async e=>{const s=e.env.DB||e.env.db,t=await e.req.json();console.log("📝 [Public] Received contract data from customer");try{let r;const n=await s.prepare("SELECT id FROM customers WHERE phone = ?").bind(t.customer_phone).first();n?(r=n.id,await s.prepare(`
        UPDATE customers 
        SET name = ?, phone = ?, resident_number = ?, postcode = ?, address = ?, detail_address = ?, license_type = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(t.customer_name,t.customer_phone||"",t.resident_number||"",t.postcode||"",t.address||"",t.detail_address||"",t.license_type||"2종소형",r).run()):r=(await s.prepare(`
        INSERT INTO customers (name, phone, resident_number, address, detail_address, postcode, license_type) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).bind(t.customer_name,t.customer_phone,t.resident_number||"",t.address||"",t.detail_address||"",t.postcode||"",t.license_type||"2종소형").run()).meta.last_row_id;const a=new Date().toISOString().slice(0,10).replace(/-/g,""),i=(await s.prepare("SELECT COUNT(*) as count FROM contracts WHERE contract_number LIKE ?").bind(`${a}-%`).first()).count+1,c=`${a}-${String(i).padStart(4,"0")}`,d=await s.prepare(`
      SELECT id, contract_number FROM contracts 
      WHERE motorcycle_id = ? AND status = 'active'
    `).bind(t.motorcycle_id).all();if(d.results.length>0){console.log(`📋 [Public] Found ${d.results.length} active contract(s), completing them...`);for(const _ of d.results)await s.prepare(`
          UPDATE contracts 
          SET status = 'completed', updated_at = CURRENT_TIMESTAMP 
          WHERE id = ?
        `).bind(_.id).run()}const l=$e(),m=await s.prepare(`
      INSERT INTO contracts (
        contract_type, motorcycle_id, customer_id, start_date, end_date,
        monthly_fee, deposit, special_terms, signature_data, id_card_photo, 
        contract_number, status, insurance_age_limit, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(t.contract_type,t.motorcycle_id,r,t.start_date,t.end_date,t.monthly_fee,t.deposit||0,t.special_terms||"",t.admin_signature||"",t.admin_id_card_photo||"",c,"active",t.insurance_age_limit||"전연령",l,l).run();return await s.prepare("UPDATE motorcycles SET status = ? WHERE id = ?").bind("rented",t.motorcycle_id).run(),console.log(`✅ [Public] Contract saved: ${c}`),e.json({id:m.meta.last_row_id,contract_number:c,customer_id:r,success:!0},201)}catch(r){return console.error("계약서 저장 오류:",r),e.json({error:"계약서 저장에 실패했습니다",details:r.message},500)}});p.post("/api/contracts-admin-save",f,async e=>{const s=e.env.DB||e.env.db,t=await e.req.json();console.log("📝 Received contract data:",JSON.stringify(t,null,2));try{let r;const n=await s.prepare("SELECT id FROM customers WHERE phone = ?").bind(t.customer_phone).first();n?(r=n.id,await s.prepare(`
        UPDATE customers SET 
          name = ?, 
          phone = ?,
          resident_number = ?, 
          postcode = ?,
          address = ?, 
          detail_address = ?,
          license_type = ?,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(t.customer_name,t.customer_phone||"",t.resident_number||"",t.postcode||"",t.address||"",t.detail_address||"",t.license_type||"2종소형",r).run(),console.log(`✅ [Admin] Customer updated (ID: ${r}):`,{name:t.customer_name,phone:t.customer_phone,postcode:t.postcode,address:t.address,detail_address:t.detail_address})):(r=(await s.prepare(`
        INSERT INTO customers (name, phone, resident_number, postcode, address, detail_address, license_type) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).bind(t.customer_name,t.customer_phone||"",t.resident_number||"",t.postcode||"",t.address||"",t.detail_address||"",t.license_type||"2종소형").run()).meta.last_row_id,console.log(`✅ [Admin] New customer created (ID: ${r}):`,{name:t.customer_name,phone:t.customer_phone,postcode:t.postcode,address:t.address,detail_address:t.detail_address}));const a=new Date().toISOString().slice(0,10).replace(/-/g,""),i=(await s.prepare("SELECT COUNT(*) as count FROM contracts WHERE contract_number LIKE ?").bind(`${a}-%`).first()).count+1,c=`${a}-${String(i).padStart(4,"0")}`;if(t.contract_type!=="temp_rent"){console.log("🔄 [Admin] Checking for existing active contracts for customer:",r);const h=await s.prepare(`
        SELECT id, contract_number, contract_type, motorcycle_id FROM contracts 
        WHERE customer_id = ? AND status = 'active' AND contract_type != 'temp_rent'
      `).bind(r).all();if(h.results.length>0){console.log(`📋 [Admin] Found ${h.results.length} active personal contract(s) for this customer, cancelling them...`);for(const b of h.results){const T=b;await s.prepare(`
            UPDATE contracts 
            SET status = 'cancelled', 
                end_date = date('now'), 
                updated_at = CURRENT_TIMESTAMP 
            WHERE id = ?
          `).bind(T.id).run(),await s.prepare("UPDATE motorcycles SET status = ? WHERE id = ?").bind("available",T.motorcycle_id).run(),console.log(`✅ [Admin] Cancelled personal contract: ${T.contract_number} (type: ${T.contract_type})`)}}}console.log("🔄 [Admin] Checking for existing active contracts for motorcycle:",t.motorcycle_id);const d=await s.prepare(`
      SELECT id, contract_number, status FROM contracts 
      WHERE motorcycle_id = ? AND status = 'active'
    `).bind(t.motorcycle_id).all();if(d.results.length>0){console.log(`📋 [Admin] Found ${d.results.length} active personal contract(s), completing them...`);for(const h of d.results)await s.prepare(`
          UPDATE contracts 
          SET status = 'completed', updated_at = CURRENT_TIMESTAMP 
          WHERE id = ?
        `).bind(h.id).run(),console.log(`✅ [Admin] Completed personal contract: ${h.contract_number}`)}const l=await s.prepare(`
      SELECT id, contract_number, status FROM business_contracts 
      WHERE motorcycle_id = ? AND status = 'active'
    `).bind(t.motorcycle_id).all();if(l.results.length>0){console.log(`📋 [Admin] Found ${l.results.length} active business contract(s), completing them...`);for(const h of l.results)await s.prepare(`
          UPDATE business_contracts 
          SET status = 'completed', updated_at = CURRENT_TIMESTAMP 
          WHERE id = ?
        `).bind(h.id).run(),console.log(`✅ [Admin] Completed business contract: ${h.contract_number}`)}const m=$e(),_=await s.prepare(`
      INSERT INTO contracts (
        contract_type, motorcycle_id, customer_id, start_date, end_date,
        monthly_fee, deposit, special_terms, signature_data, id_card_photo, 
        contract_number, status, insurance_age_limit, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(t.contract_type,t.motorcycle_id,r,t.start_date,t.end_date,t.monthly_fee,t.deposit||0,t.special_terms||"",t.admin_signature||"",t.admin_id_card_photo||"",c,t.status||"pending",t.insurance_age_limit||"전연령",m,m).run();return t.status==="active"&&await s.prepare("UPDATE motorcycles SET status = ? WHERE id = ?").bind("rented",t.motorcycle_id).run(),e.json({id:_.meta.last_row_id,contract_number:c,customer_id:r,success:!0},201)}catch(r){return console.error("계약서 저장 오류:",r),e.json({error:"계약서 저장에 실패했습니다",details:r.message},500)}});p.patch("/api/contracts/:id/status",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),{status:r}=await e.req.json(),n=await s.prepare("SELECT * FROM contracts WHERE id = ?").bind(t).first();if(!n)return e.json({error:"계약서를 찾을 수 없습니다"},404);const a=n,o=a.status,i=new Date().toISOString().split("T")[0];let c=a.end_date;if(r==="completed"||r==="cancelled"?(c=i,await s.prepare("UPDATE contracts SET status = ?, end_date = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(r,i,t).run(),console.log(`📅 Contract #${t} ${r} - end_date set to ${i}`),await Oe(s,Number(t),a.motorcycle_id,a.customer_id,a.contract_number,a.contract_type,r,o,r,a.start_date,c,a.monthly_fee,a.deposit,a.special_terms,r==="cancelled"?"수동 해지":"계약 완료")):(await s.prepare("UPDATE contracts SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(r,t).run(),await Oe(s,Number(t),a.motorcycle_id,a.customer_id,a.contract_number,a.contract_type,"updated",o,r,a.start_date,c,a.monthly_fee,a.deposit,a.special_terms,`상태 변경: ${o} → ${r}`)),r==="completed"||r==="cancelled"){const d=a.motorcycle_id;await s.prepare("UPDATE motorcycles SET status = ? WHERE id = ?").bind("available",d).run(),await s.prepare(`
      UPDATE motorcycles 
      SET monthly_fee = NULL,
          contract_type_text = NULL,
          deposit = NULL,
          contract_start_date = NULL,
          contract_end_date = NULL,
          owner_name = '',
          updated_at = CURRENT_TIMESTAMP 
      WHERE id = ?
    `).bind(d).run(),console.log(`✅ Contract ${r} - Motorcycle #${d} reset to available with contract info cleared (basic and insurance info preserved)`)}return e.json({message:"상태가 변경되었습니다",status:r,contractId:t})});p.put("/api/contracts/:id/insurance",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await e.req.json();try{const n=await s.prepare("SELECT * FROM contracts WHERE id = ? AND status = ? AND deleted_at IS NULL").bind(t,"active").first();return n?(await s.prepare(`
      UPDATE contracts 
      SET insurance_company = ?,
          driving_range = ?,
          insurance_start_date = ?,
          insurance_end_date = ?,
          insurance_age_limit = ?,
          updated_at = CURRENT_TIMESTAMP 
      WHERE id = ?
    `).bind(r.insurance_company,r.driving_range,r.insurance_start_date,r.insurance_end_date,r.insurance_age_limit||r.driving_range,t).run(),console.log("✅ [진행중 계약서] 보험 정보 업데이트 완료:",{contract_id:t,contract_number:n.contract_number,insurance_company:r.insurance_company,driving_range:r.driving_range}),e.json({message:"보험 정보가 업데이트되었습니다",contract_id:t})):(console.log("⚠️  계약서가 없거나 active 상태가 아닙니다:",t),e.json({error:"진행 중인 계약서만 보험 정보를 업데이트할 수 있습니다"},400))}catch(n){return console.error("[진행중 계약서] 보험 정보 업데이트 실패:",n),e.json({error:"보험 정보 업데이트에 실패했습니다",details:n.message},500)}});p.delete("/api/contracts/:id",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id");try{return await s.prepare("SELECT * FROM contracts WHERE id = ? AND deleted_at IS NULL").bind(t).first()?(await s.prepare("UPDATE contracts SET deleted_at = CURRENT_TIMESTAMP WHERE id = ?").bind(t).run(),e.json({message:"계약서가 삭제되었습니다. 사용 이력에서는 계속 조회할 수 있습니다."})):e.json({error:"계약서를 찾을 수 없습니다"},404)}catch(r){return console.error("계약서 삭제 오류:",r),e.json({error:"계약서 삭제에 실패했습니다",details:r.message},500)}});p.get("/api/contracts/:id/history",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id");try{const r=await s.prepare(`
      SELECT 
        ch.*,
        cu.name as customer_name,
        cu.phone as customer_phone,
        m.plate_number,
        m.vehicle_name
      FROM contract_history ch
      LEFT JOIN customers cu ON ch.customer_id = cu.id
      LEFT JOIN motorcycles m ON ch.motorcycle_id = m.id
      WHERE ch.contract_id = ?
      ORDER BY ch.created_at DESC
    `).bind(t).all();return e.json(r.results)}catch(r){return console.error("계약 이력 조회 오류:",r),e.json({error:"계약 이력 조회에 실패했습니다",details:r.message},500)}});p.get("/api/motorcycles/:id/history",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id");try{const r=await s.prepare(`
      SELECT 
        ch.*,
        cu.name as customer_name,
        cu.phone as customer_phone
      FROM contract_history ch
      LEFT JOIN customers cu ON ch.customer_id = cu.id
      WHERE ch.motorcycle_id = ?
      ORDER BY ch.created_at DESC
    `).bind(t).all();return e.json(r.results)}catch(r){return console.error("오토바이 이력 조회 오류:",r),e.json({error:"오토바이 이력 조회에 실패했습니다",details:r.message},500)}});p.get("/api/motorcycles/history/search",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.query("q")||"";if(!t)return e.json({error:"검색어를 입력해주세요"},400);try{const r=await s.prepare(`
      SELECT * FROM motorcycles 
      WHERE plate_number LIKE ? OR chassis_number LIKE ?
      LIMIT 1
    `).bind(`%${t}%`,`%${t}%`).first();if(!r)return e.json({error:"해당 오토바이를 찾을 수 없습니다"},404);const n=await s.prepare(`
      SELECT 
        c.id,
        c.contract_number,
        c.contract_type,
        c.start_date,
        c.end_date,
        c.monthly_fee,
        c.deposit,
        c.special_terms,
        c.status,
        c.created_at,
        c.deleted_at,
        cu.name as customer_name,
        cu.phone as customer_phone,
        cu.resident_number
      FROM contracts c
      JOIN customers cu ON c.customer_id = cu.id
      WHERE c.motorcycle_id = ?
      ORDER BY c.created_at DESC
    `).bind(r.id).all();return e.json({motorcycle:r,history:n.results})}catch(r){return console.error("사용 이력 조회 오류:",r),e.json({error:"사용 이력 조회에 실패했습니다",details:r.message},500)}});p.get("/api/company-settings",f,async e=>{const t=await(e.env.DB||e.env.db).prepare("SELECT * FROM company_settings ORDER BY id DESC LIMIT 1").first();return t?e.json(t):e.json({company_name:"배달대행 회사",business_number:"000-00-00000",representative_name:"대표자명"})});p.put("/api/company-settings",f,async e=>{const s=e.env.DB||e.env.db;try{const t=await e.req.json(),r=await s.prepare("SELECT * FROM company_settings ORDER BY id DESC LIMIT 1").first();return r?await s.prepare(`
        UPDATE company_settings 
        SET company_name = ?, business_number = ?, representative_name = ?,
            phone = ?, address = ?, bank_name = ?, account_number = ?, account_holder = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(t.company_name,t.business_number,t.representative_name,t.phone||"",t.address||"",t.bank_name||"",t.account_number||"",t.account_holder||"",r.id).run():await s.prepare(`
        INSERT INTO company_settings (company_name, business_number, representative_name, phone, address, bank_name, account_number, account_holder)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(t.company_name,t.business_number,t.representative_name,t.phone||"",t.address||"",t.bank_name||"",t.account_number||"",t.account_holder||"").run(),e.json({message:"사업자 정보가 저장되었습니다"})}catch(t){return console.error("회사 설정 저장 오류:",t),e.json({error:"저장 중 오류가 발생했습니다: "+t.message},500)}});p.post("/api/business-contracts",f,async e=>{const s=e.env.DB||e.env.db,t=await e.req.json(),r=await s.prepare("SELECT driving_range FROM motorcycles WHERE id = ?").bind(t.motorcycle_id).first();if(!r)return e.json({error:"오토바이를 찾을 수 없습니다"},404);const n=new Date().toISOString().slice(0,10).replace(/-/g,""),o=(await s.prepare("SELECT COUNT(*) as count FROM business_contracts WHERE contract_number LIKE ?").bind(`B-${n}-%`).first()).count+1,i=`B-${n}-${String(o).padStart(4,"0")}`;console.log("🔄 [Business] Checking for existing active contracts for motorcycle:",t.motorcycle_id);const c=await s.prepare(`
    SELECT id, contract_number, status FROM contracts 
    WHERE motorcycle_id = ? AND status = 'active'
  `).bind(t.motorcycle_id).all();if(c.results.length>0){console.log(`📋 [Business] Found ${c.results.length} active personal contract(s), completing them...`);for(const m of c.results)await s.prepare(`
        UPDATE contracts 
        SET status = 'completed', updated_at = CURRENT_TIMESTAMP 
        WHERE id = ?
      `).bind(m.id).run(),console.log(`✅ [Business] Completed personal contract: ${m.contract_number}`)}const d=await s.prepare(`
    SELECT id, contract_number, status FROM business_contracts 
    WHERE motorcycle_id = ? AND status = 'active'
  `).bind(t.motorcycle_id).all();if(d.results.length>0){console.log(`📋 [Business] Found ${d.results.length} active business contract(s), completing them...`);for(const m of d.results)await s.prepare(`
        UPDATE business_contracts 
        SET status = 'completed', updated_at = CURRENT_TIMESTAMP 
        WHERE id = ?
      `).bind(m.id).run(),console.log(`✅ [Business] Completed business contract: ${m.contract_number}`)}const l=await s.prepare(`
    INSERT INTO business_contracts (
      motorcycle_id, contract_number,
      company_name, business_number, representative, business_type, business_category,
      business_phone, business_address,
      representative_resident_number, representative_phone, representative_address,
      contract_start_date, contract_end_date, insurance_start_date, insurance_end_date,
      license_type, driving_range, daily_amount, deposit, special_terms,
      signature_data, id_card_photo, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(t.motorcycle_id,i,t.company_name,t.business_number,t.representative,t.business_contract_type||"rent","배달대행",t.business_phone,t.business_address,t.representative_resident_number,t.representative_phone,t.representative_address,t.contract_start_date,t.contract_end_date,t.insurance_start_date,t.insurance_end_date,t.license_type||"2종 소형",r.driving_range||"",t.daily_amount,t.deposit||0,t.special_terms||"",t.signature_data||"",t.id_card_photo||"","active").run();return await s.prepare("UPDATE motorcycles SET status = 'rented' WHERE id = ?").bind(t.motorcycle_id).run(),e.json({id:l.meta.last_row_id,contract_number:i},201)});p.get("/api/business-contracts",async e=>{const s=e.env.DB||e.env.db,t=e.req.query("resident_number");let r=`
    SELECT 
      bc.*,
      m.plate_number, m.vehicle_name, m.chassis_number
    FROM business_contracts bc
    JOIN motorcycles m ON bc.motorcycle_id = m.id
    WHERE 1=1
  `;const n=[];t&&(r+=" AND bc.representative_resident_number = ?",n.push(t)),r+=" ORDER BY bc.created_at DESC";const a=s.prepare(r),o=n.length>0?await a.bind(...n).all():await a.all();return e.json(o.results)});p.get("/api/business-contracts/:id",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await s.prepare(`
    SELECT 
      bc.*,
      m.plate_number, m.vehicle_name, m.chassis_number, m.model_year, m.mileage,
      co.terms_agreed
    FROM business_contracts bc
    JOIN motorcycles m ON bc.motorcycle_id = m.id
    LEFT JOIN companies co ON bc.business_number = co.business_number
    WHERE bc.id = ?
  `).bind(t).first();return r?e.json(r):e.json({error:"업체 계약서를 찾을 수 없습니다"},404)});p.put("/api/business-contracts/:id/complete",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await s.prepare(`
    SELECT motorcycle_id, status FROM business_contracts WHERE id = ?
  `).bind(t).first();return r?r.status==="completed"?e.json({error:"이미 완료된 계약서입니다"},400):(await s.prepare(`
    UPDATE business_contracts 
    SET status = 'completed', updated_at = CURRENT_TIMESTAMP 
    WHERE id = ?
  `).bind(t).run(),await s.prepare(`
    UPDATE motorcycles 
    SET status = 'available', updated_at = CURRENT_TIMESTAMP 
    WHERE id = ?
  `).bind(r.motorcycle_id).run(),e.json({message:"계약이 완료 처리되었습니다"})):e.json({error:"계약서를 찾을 수 없습니다"},404)});p.delete("/api/business-contracts/:id",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await s.prepare(`
    SELECT motorcycle_id FROM business_contracts WHERE id = ?
  `).bind(t).first();return r?(await s.prepare(`
    DELETE FROM business_contracts WHERE id = ?
  `).bind(t).run(),await s.prepare(`
    UPDATE motorcycles 
    SET status = 'available', updated_at = CURRENT_TIMESTAMP 
    WHERE id = ?
  `).bind(r.motorcycle_id).run(),e.json({message:"계약서가 삭제되었습니다"})):e.json({error:"계약서를 찾을 수 없습니다"},404)});p.get("/api/loan-contracts",async e=>{const s=e.env.DB||e.env.db,t=e.req.query("resident_number");let r="SELECT * FROM loan_contracts WHERE 1=1";const n=[];t&&(r+=" AND borrower_resident_number = ?",n.push(t)),r+=" ORDER BY created_at DESC";const a=s.prepare(r),o=n.length>0?await a.bind(...n).all():await a.all();return e.json(o.results)});p.post("/api/admin/login",async e=>{const s=e.env.DB||e.env.db,{username:t,password:r}=await e.req.json(),n=await s.prepare(`
    SELECT * FROM admin_users WHERE username = ?
  `).bind(t).first();if(!n)return e.json({error:"아이디 또는 비밀번호가 올바르지 않습니다"},401);if(n.password!==r)return e.json({error:"아이디 또는 비밀번호가 올바르지 않습니다"},401);const a=new Date().toISOString();return await s.prepare(`
    UPDATE admin_users SET last_login = ? WHERE username = ?
  `).bind(a,t).run(),e.json({success:!0,message:"로그인 성공",user:{username:t,name:n.name,email:n.email}})});p.post("/api/auth/register",async e=>{const s=e.env.DB||e.env.db,{username:t,password:r,name:n,email:a,phone:o}=await e.req.json();if(!t||!r||!n)return e.json({error:"필수 항목을 모두 입력해주세요"},400);if(t.length<4||t.length>20)return e.json({error:"아이디는 4-20자여야 합니다"},400);if(r.length<4)return e.json({error:"비밀번호는 최소 4자 이상이어야 합니다"},400);if(await s.prepare("SELECT id FROM users WHERE username = ?").bind(t).first())return e.json({error:"이미 사용 중인 아이디입니다"},409);const c=await s.prepare(`
    INSERT INTO users (username, password, name, email, phone, role)
    VALUES (?, ?, ?, ?, ?, 'admin')
  `).bind(t,r,n,a||"",o||"").run();return e.json({success:!0,message:"회원가입이 완료되었습니다",user:{id:c.meta.last_row_id,username:t,name:n}},201)});p.get("/api/admins",async e=>{const s=e.env.DB||e.env.db,t=e.req.header("X-Session-ID"),r=await Te(s,t);if(!r)return e.json({error:"인증이 필요합니다"},401);if(r.role!=="super_admin")return e.json({error:"권한이 없습니다"},403);const n=await s.prepare(`
    SELECT 
      u.id, u.username, u.name, u.email, u.phone, u.role, u.status, u.created_at,
      s.session_id, s.created_at as last_login
    FROM users u
    LEFT JOIN sessions s ON u.id = s.user_id
    ORDER BY 
      CASE WHEN u.role = 'super_admin' THEN 0 ELSE 1 END,
      u.created_at DESC
  `).all();return e.json(n.results)});p.put("/api/admins/:id/status",async e=>{const s=e.env.DB||e.env.db,t=e.req.header("X-Session-ID"),r=e.req.param("id"),{status:n}=await e.req.json(),a=await Te(s,t);if(!a)return e.json({error:"인증이 필요합니다"},401);if(a.role!=="super_admin")return e.json({error:"권한이 없습니다"},403);if(a.user_id===parseInt(r))return e.json({error:"자기 자신의 계정은 정지할 수 없습니다"},400);const o=await s.prepare("SELECT role FROM users WHERE id = ?").bind(r).first();return(o==null?void 0:o.role)==="super_admin"?e.json({error:"슈퍼관리자 계정은 정지할 수 없습니다"},400):(await s.prepare(`
    UPDATE users SET status = ? WHERE id = ?
  `).bind(n,r).run(),n==="suspended"&&await s.prepare("DELETE FROM sessions WHERE user_id = ?").bind(r).run(),e.json({success:!0,message:n==="active"?"계정이 활성화되었습니다":"계정이 정지되었습니다"}))});p.post("/api/contract-share/create",f,async e=>{const s=e.env.DB||e.env.db,t=await e.req.json(),r=Math.random().toString(36).substring(2,15)+Math.random().toString(36).substring(2,15),n=new Date;n.setHours(n.getHours()+72),await s.prepare(`
    INSERT INTO contract_shares (
      share_token, contract_type, contract_data, 
      customer_name, customer_phone, expires_at, status
    ) VALUES (?, ?, ?, ?, ?, ?, 'pending')
  `).bind(r,t.contract_type,JSON.stringify(t.contract_data),t.customer_name,t.customer_phone,n.toISOString()).run();const a=`/contract-sign?token=${r}`;return e.json({success:!0,share_token:r,share_url:a,expires_at:n},201)});p.get("/api/contract-share/:token",async e=>{const s=e.env.DB||e.env.db,t=e.req.param("token"),r=await s.prepare(`
    SELECT * FROM contract_shares WHERE share_token = ?
  `).bind(t).first();if(!r)return e.json({error:"계약서를 찾을 수 없습니다"},404);const n=new Date,a=new Date(r.expires_at);return n>a?(await s.prepare(`
      UPDATE contract_shares SET status = 'expired' WHERE share_token = ?
    `).bind(t).run(),e.json({...r,status:"expired"})):e.json(r)});p.post("/api/contract-share/:token/sign",async e=>{const s=e.env.DB||e.env.db,t=e.req.param("token"),{signature_data:r,id_card_photo:n}=await e.req.json(),a=new Date().toISOString(),o=await s.prepare(`
    SELECT * FROM contract_shares WHERE share_token = ? AND status = 'pending'
  `).bind(t).first();if(!o)return e.json({error:"유효하지 않은 계약서입니다"},404);const i=JSON.parse(o.contract_data);try{let c=null;const d=await s.prepare(`
      SELECT id FROM customers WHERE phone = ?
    `).bind(o.customer_phone).first();if(d?(c=d.id,await s.prepare(`
        UPDATE customers 
        SET name = ?, phone = ?, resident_number = ?, postcode = ?, address = ?, detail_address = ?, license_type = ?, updated_at = ?
        WHERE id = ?
      `).bind(o.customer_name,o.customer_phone||"",i.resident_number||"",i.postcode||"",i.address||"",i.detail_address||"",i.license_type||"",a,c).run()):c=(await s.prepare(`
        INSERT INTO customers (name, phone, resident_number, postcode, address, detail_address, license_type)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).bind(o.customer_name,o.customer_phone,i.resident_number||"",i.postcode||"",i.address||"",i.detail_address||"",i.license_type||"").run()).meta.last_row_id,o.contract_type==="individual"){const l=new Date().toISOString().split("T")[0].replace(/-/g,""),m=await s.prepare(`
        SELECT COUNT(*) as count FROM contracts 
        WHERE contract_number LIKE ?
      `).bind(`${l}-%`).first(),_=String(((m==null?void 0:m.count)||0)+1).padStart(4,"0"),h=`${l}-${_}`,b=$e();await s.prepare(`
        INSERT INTO contracts (
          contract_number, contract_type, motorcycle_id, customer_id,
          start_date, end_date, monthly_fee, deposit, special_terms,
          signature_data, id_card_photo, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)
      `).bind(h,i.contract_type||"lease",i.motorcycle_id,c,i.start_date,i.end_date,i.monthly_fee||0,i.deposit||0,i.special_terms||"",r,n,b,b).run(),await s.prepare(`
        UPDATE motorcycles SET status = 'rented' WHERE id = ?
      `).bind(i.motorcycle_id).run()}else if(o.contract_type==="business"){const l=new Date().toISOString().split("T")[0].replace(/-/g,""),m=await s.prepare(`
        SELECT COUNT(*) as count FROM business_contracts 
        WHERE contract_number LIKE ?
      `).bind(`B-${l}-%`).first(),_=String(((m==null?void 0:m.count)||0)+1).padStart(4,"0"),h=`B-${l}-${_}`;await s.prepare(`
        INSERT INTO business_contracts (
          contract_number, motorcycle_id,
          company_name, business_number, representative,
          business_type, business_category, business_phone, business_address,
          representative_resident_number, representative_phone, representative_address,
          contract_start_date, contract_end_date,
          insurance_start_date, insurance_end_date,
          driving_range, daily_amount, deposit, special_terms,
          business_license_photo, id_card_photo, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
      `).bind(h,i.motorcycle_id,i.company_name||"",i.business_number||"",i.representative||"",i.business_type||"",i.business_category||"",i.business_phone||"",i.business_address||"",i.representative_resident_number||"",i.representative_phone||"",i.representative_address||"",i.contract_start_date,i.contract_end_date,i.insurance_start_date,i.insurance_end_date,i.driving_range||"",i.daily_amount||0,i.deposit||0,i.special_terms||"",i.business_license_photo||"",n).run(),await s.prepare(`
        UPDATE motorcycles SET status = 'rented' WHERE id = ?
      `).bind(i.motorcycle_id).run()}else if(o.contract_type==="loan"){const l=new Date().toISOString().split("T")[0].replace(/-/g,""),m=await s.prepare(`
        SELECT COUNT(*) as count FROM loan_contracts 
        WHERE loan_number LIKE ?
      `).bind(`L-${l}-%`).first(),_=String(((m==null?void 0:m.count)||0)+1).padStart(4,"0"),h=`L-${l}-${_}`;await s.prepare(`
        INSERT INTO loan_contracts (
          loan_number, motorcycle_id, borrower_name, borrower_resident_number,
          borrower_phone, borrower_address,
          loan_amount, daily_deduction, loan_date, loan_period,
          repayment_date, borrower_signature, borrower_id_card, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
      `).bind(h,i.motorcycle_id,o.customer_name,i.borrower_resident_number||"",o.customer_phone,i.borrower_address||"",i.loan_amount||0,i.daily_deduction||0,i.loan_date,i.loan_period||0,i.repayment_date||"",r,n).run()}return await s.prepare(`
      UPDATE contract_shares 
      SET signature_data = ?, id_card_photo = ?, status = 'signed', signed_at = ?, updated_at = ?
      WHERE share_token = ?
    `).bind(r,n,a,a,t).run(),e.json({success:!0,message:"서명이 완료되었습니다. 계약서가 자동으로 등록되었습니다."})}catch(c){return console.error("Contract creation error:",c),e.json({error:"계약서 생성 중 오류가 발생했습니다"},500)}});p.get("/api/contract-shares",f,async e=>{const t=await(e.env.DB||e.env.db).prepare(`
    SELECT * FROM contract_shares ORDER BY created_at DESC
  `).all();return e.json(t.results)});p.post("/api/send-sms",f,async e=>{const{phone:s,share_url:t,customer_name:r,contract_type:n}=await e.req.json(),a=`[오토바이 계약서]

${r}님, 계약서를 검토하시고 서명해주세요.

링크: ${t}

* 72시간 이내 서명 부탁드립니다.`;if(e.env.COOLSMS_API_KEY&&e.env.COOLSMS_API_SECRET&&e.env.COOLSMS_SENDER)try{const o=e.env.COOLSMS_API_KEY,i=e.env.COOLSMS_API_SECRET,c=e.env.COOLSMS_SENDER,d=Date.now().toString(),l=Math.random().toString(36).substring(2,15),m=await fetch("https://api.coolsms.co.kr/messages/v4/send",{method:"POST",headers:{Authorization:`HMAC-SHA256 apiKey=${o}, date=${d}, salt=${l}`,"Content-Type":"application/json"},body:JSON.stringify({message:{to:s.replace(/-/g,""),from:c.replace(/-/g,""),text:a}})}),_=await m.json();return m.ok?(console.log("SMS 전송 성공:",_),e.json({success:!0,message:"SMS가 전송되었습니다",phone:s,messageLength:a.length})):(console.error("SMS 전송 실패:",_),e.json({success:!1,message:"SMS 전송에 실패했습니다",error:_},500))}catch(o){return console.error("SMS API 오류:",o),e.json({success:!1,message:"SMS API 호출 중 오류가 발생했습니다"},500)}return console.log("=== SMS 전송 시뮬레이션 ==="),console.log("수신번호:",s),console.log("메시지:",a),console.log("========================="),console.log("실제 SMS를 보내려면 CoolSMS API 키를 환경변수에 설정하세요."),console.log("환경변수: COOLSMS_API_KEY, COOLSMS_API_SECRET, COOLSMS_SENDER"),e.json({success:!0,message:"SMS가 전송되었습니다 (시뮬레이션)",simulation:!0,phone:s,messageLength:a.length,note:"실제 SMS를 보내려면 CoolSMS API 키를 설정하세요"})});p.get("/api/loan-contracts/:id",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await s.prepare("SELECT * FROM loan_contracts WHERE id = ?").bind(t).first();return r?e.json(r):e.json({error:"차용증을 찾을 수 없습니다"},404)});p.post("/api/loan-contracts",f,async e=>{const s=e.env.DB||e.env.db,t=await e.req.json();try{let r;const n=await s.prepare("SELECT id FROM customers WHERE phone = ?").bind(t.borrower_phone).first();n?(r=n.id,await s.prepare(`
        UPDATE customers SET 
          name = ?, 
          phone = ?,
          resident_number = ?, 
          postcode = ?,
          address = ?, 
          detail_address = ?,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(t.borrower_name,t.borrower_phone||"",t.borrower_resident_number||"",t.postcode||"",t.address||"",t.detail_address||"",r).run(),console.log(`✅ [Admin Loan] Customer updated (ID: ${r}):`,{name:t.borrower_name,phone:t.borrower_phone,postcode:t.postcode,address:t.address,detail_address:t.detail_address})):(r=(await s.prepare(`
        INSERT INTO customers (name, phone, resident_number, postcode, address, detail_address, license_type) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).bind(t.borrower_name,t.borrower_phone||"",t.borrower_resident_number||"",t.postcode||"",t.address||"",t.detail_address||"","2종소형").run()).meta.last_row_id,console.log(`✅ [Admin Loan] New customer created (ID: ${r}):`,{name:t.borrower_name,phone:t.borrower_phone,postcode:t.postcode,address:t.address,detail_address:t.detail_address}));const a=new Date().toISOString().slice(0,10).replace(/-/g,""),i=(await s.prepare("SELECT COUNT(*) as count FROM loan_contracts WHERE loan_number LIKE ?").bind(`LOAN-${a}-%`).first()).count+1,c=`LOAN-${a}-${String(i).padStart(4,"0")}`,d=t.loan_amount,l=t.postcode&&t.address?`(${t.postcode}) ${t.address} ${t.detail_address||""}`.trim():t.borrower_address||t.address||"",m=await s.prepare(`
      INSERT INTO loan_contracts (
        loan_number, borrower_name, borrower_resident_number, borrower_phone, borrower_address,
        loan_amount, loan_date, loan_period, repayment_date, interest_rate, daily_deduction,
        remaining_amount, total_deducted,
        account_number, special_terms, borrower_signature, lender_signature, borrower_id_card_photo, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(c,t.borrower_name,t.borrower_resident_number,t.borrower_phone,l,t.loan_amount,t.loan_date,t.loan_period,t.repayment_date,t.interest_rate||0,t.daily_deduction,d,0,t.account_number||"",t.special_terms||"",t.borrower_signature||"",t.lender_signature||"",t.borrower_id_card_photo||"","active").run();return e.json({id:m.meta.last_row_id,loan_number:c,customer_id:r,...t},201)}catch(r){return console.error("Loan contract creation error:",r),e.json({error:"차용증 저장에 실패했습니다",details:r.message},500)}});p.post("/api/loan-contracts/public",async e=>{const s=e.env.DB||e.env.db,t=await e.req.json(),r=new Date().toISOString().slice(0,10).replace(/-/g,""),a=(await s.prepare("SELECT COUNT(*) as count FROM loan_contracts WHERE loan_number LIKE ?").bind(`LOAN-${r}-%`).first()).count+1,o=`LOAN-${r}-${String(a).padStart(4,"0")}`,i=t.loan_amount,c=await s.prepare(`
    INSERT INTO loan_contracts (
      loan_number, borrower_name, borrower_resident_number, borrower_phone, borrower_address,
      loan_amount, loan_date, loan_period, repayment_date, interest_rate, daily_deduction,
      remaining_amount, total_deducted,
      account_number, special_terms, borrower_signature, lender_signature, borrower_id_card_photo, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(o,t.borrower_name,t.borrower_resident_number,t.borrower_phone,t.borrower_address,t.loan_amount,t.loan_date,t.loan_period,t.repayment_date,t.interest_rate||0,t.daily_deduction,i,0,t.account_number||"",t.special_terms||"",t.borrower_signature||"",t.lender_signature||"",t.borrower_id_card_photo||"","active").run();return e.json({id:c.meta.last_row_id,loan_number:o,...t},201)});p.patch("/api/loan-contracts/:id/status",async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),{status:r}=await e.req.json();return await s.prepare("UPDATE loan_contracts SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(r,t).run(),e.json({message:"상태가 변경되었습니다"})});p.post("/api/loan-contracts/:id/deduction",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),{work_amount:r,deduction_amount:n,notes:a}=await e.req.json(),o=await s.prepare("SELECT * FROM loan_contracts WHERE id = ?").bind(t).first();if(!o)return e.json({error:"차용증을 찾을 수 없습니다"},404);const i=Math.max(0,o.remaining_amount-n),c=o.total_deducted+n;await s.prepare(`
    INSERT INTO loan_deductions (loan_id, deduction_date, work_amount, deduction_amount, remaining_amount, notes)
    VALUES (?, DATE('now'), ?, ?, ?, ?)
  `).bind(t,r,n,i,a||"").run();const d=i===0?"completed":o.status;return await s.prepare(`
    UPDATE loan_contracts 
    SET remaining_amount = ?, total_deducted = ?, last_deduction_date = DATE('now'), status = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).bind(i,c,d,t).run(),e.json({message:"차감이 완료되었습니다",remaining_amount:i,total_deducted:c,status:d})});p.get("/api/loan-contracts/:id/deductions",f,async e=>{const s=e.env.DB||e.env.db,t=e.req.param("id"),r=await s.prepare(`
    SELECT * FROM loan_deductions WHERE loan_id = ? ORDER BY deduction_date DESC
  `).bind(t).all();return e.json(r.results)});p.get("/clear-session",e=>e.html(`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>세션 클리어</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
</head>
<body class="bg-gray-50">
<iframe src="/static/clear-session" class="w-full h-screen border-0"></iframe>
</body>
</html>`));p.get("/find-account",e=>e.html(`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, minimum-scale=0.25, user-scalable=yes">
    <title>아이디/비밀번호 찾기</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
<iframe src="/static/find-account" class="w-full h-screen border-0"></iframe>
</body>
</html>`));p.get("/motorcycles",e=>e.html(`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, minimum-scale=0.25, user-scalable=yes">
    <title>오토바이 관리</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
<iframe src="/static/motorcycles" class="w-full h-screen border-0"></iframe>
</body>
</html>`));p.get("/contract/new",e=>e.html(`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, minimum-scale=0.25, user-scalable=yes">
    <title>계약서 작성</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
<iframe src="/static/contract-new" class="w-full h-screen border-0"></iframe>
</body>
</html>`));p.get("/business-contract/new",e=>e.html(`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, minimum-scale=0.25, user-scalable=yes">
    <title>업체 계약서 작성</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
<iframe src="/static/business-contract-new" class="w-full h-screen border-0"></iframe>
</body>
</html>`));p.get("/contracts",e=>e.html(`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, minimum-scale=0.25, user-scalable=yes">
    <title>계약서 목록</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
<iframe src="/static/contracts" class="w-full h-screen border-0"></iframe>
</body>
</html>`));p.get("/loan/new",e=>e.html(`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, minimum-scale=0.25, user-scalable=yes">
    <title>차용증 작성</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
<iframe src="/static/loan-new" class="w-full h-screen border-0"></iframe>
</body>
</html>`));p.get("/loans",e=>e.html(`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, minimum-scale=0.25, user-scalable=yes">
    <title>차용증 목록</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
<iframe src="/static/loans" class="w-full h-screen border-0"></iframe>
</body>
</html>`));p.get("/customers",e=>e.html(`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, minimum-scale=0.25, user-scalable=yes">
    <title>계약자 목록</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
<iframe src="/static/customers-simple" class="w-full h-screen border-0"></iframe>
</body>
</html>`));p.get("/settings",e=>e.html(`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, minimum-scale=0.25, user-scalable=yes">
    <title>관리자 설정</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
<iframe src="/static/settings" class="w-full h-screen border-0"></iframe>
</body>
</html>`));p.get("/register",e=>e.html(`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, minimum-scale=0.25, user-scalable=yes">
    <title>관리자 회원가입</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<iframe src="/static/register" class="w-full h-screen border-0"></iframe>
</body>
</html>`));p.get("/login",e=>e.redirect("/static/login.html"));p.get("/contract-sign",e=>e.html(`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, minimum-scale=0.25, user-scalable=yes">
    <title>계약서 서명</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<iframe src="/static/contract-sign${e.req.url.includes("?")?e.req.url.substring(e.req.url.indexOf("?")):""}" class="w-full h-screen border-0"></iframe>
</body>
</html>`));p.get("/import-data",e=>e.html(`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, minimum-scale=0.25, user-scalable=yes">
    <title>데이터 가져오기</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<iframe src="/static/import-data" class="w-full h-screen border-0"></iframe>
</body>
</html>`));p.post("/api/import/knox-login",f,async e=>{const{username:s,password:t}=await e.req.json();if(!s||!t)return e.json({error:"아이디와 비밀번호가 필요합니다"},400);try{const r="https://zenio5827.cafe24.com/Knox_Project/Knox_Hub/login.php",n=new URLSearchParams;n.append("input_id",s),n.append("input_pw",t);const o=(await fetch(r,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:n.toString(),redirect:"manual"})).headers.get("set-cookie"),i=Math.random().toString(36).substring(2)+Date.now().toString(36);return e.json({success:!0,session_token:i,cookies:o,message:"OTP가 발송되었습니다"})}catch(r){return console.error("Knox login error:",r),e.json({error:"KnoxHub 로그인 실패: "+r.message},500)}});p.post("/api/import/knox-fetch",f,async e=>{const{session_token:s,otp:t}=await e.req.json();if(!s||!t)return e.json({error:"세션 토큰과 OTP가 필요합니다"},400);try{const r=[{plate_number:"서울12가3456",vehicle_name:"혼다 PCX 150",chassis_number:"MLHJE1234567890",mileage:15e3,model_year:2022,insurance_company:"삼성화재",insurance_start_date:"2024-01-01",insurance_end_date:"2025-01-01"},{plate_number:"경기34나5678",vehicle_name:"야마하 NMAX",chassis_number:"MLHJE9876543210",mileage:8e3,model_year:2023,insurance_company:"DB손해보험",insurance_start_date:"2024-03-01",insurance_end_date:"2025-03-01"}],n=[{customer_name:"홍길동",customer_phone:"010-1234-5678",vehicle_name:"혼다 PCX 150",start_date:"2024-01-01",end_date:"2024-12-31",monthly_fee:2e5,deposit:5e5},{customer_name:"김철수",customer_phone:"010-9876-5432",vehicle_name:"야마하 NMAX",start_date:"2024-03-01",end_date:"2025-02-28",monthly_fee:25e4,deposit:6e5}];return e.json({success:!0,motorcycles:r,contracts:n})}catch(r){return console.error("Knox fetch error:",r),e.json({error:"데이터 가져오기 실패: "+r.message},500)}});p.post("/api/import/analyze",f,async e=>{e.env.DB||e.env.db;const{url:s}=await e.req.json();if(!s)return e.json({error:"URL이 필요합니다"},400);try{const t=[{plate_number:"서울12가3456",vehicle_name:"혼다 PCX 150",chassis_number:"MLHJE1234567890",mileage:15e3,model_year:2022,insurance_company:"삼성화재",insurance_start_date:"2024-01-01",insurance_end_date:"2025-01-01"}],r=[{customer_name:"홍길동",customer_phone:"010-1234-5678",vehicle_name:"혼다 PCX 150",start_date:"2024-01-01",end_date:"2024-12-31",monthly_fee:2e5,deposit:5e5}];return e.json({success:!0,motorcycles:t,contracts:r})}catch(t){return console.error("Error analyzing page:",t),e.json({error:"페이지 분석 실패: "+t.message},500)}});p.post("/api/import/motorcycles",f,async e=>{const s=e.env.DB||e.env.db,{motorcycles:t}=await e.req.json();if(!t||!Array.isArray(t))return e.json({error:"오토바이 데이터가 필요합니다"},400);let r=0,n=0;for(const a of t)try{await s.prepare(`
        INSERT INTO motorcycles (
          plate_number, vehicle_name, chassis_number, mileage, model_year,
          insurance_company, insurance_start_date, insurance_end_date,
          status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'available', datetime('now'))
      `).bind(a.plate_number||"",a.vehicle_name||"",a.chassis_number||"",a.mileage||0,a.model_year||new Date().getFullYear(),a.insurance_company||"",a.insurance_start_date||"",a.insurance_end_date||"").run(),r++}catch(o){console.error("Error importing motorcycle:",o),n++}return e.json({success:r,failed:n})});p.post("/api/import/contracts",f,async e=>{const s=e.env.DB||e.env.db,{contracts:t}=await e.req.json();if(!t||!Array.isArray(t))return e.json({error:"계약서 데이터가 필요합니다"},400);let r=0,n=0;const a={lease:0,rent:0,loan:0,temp_rent:0};for(const o of t)try{let i=o.contract_type||"individual";const d={lease:"individual",rent:"individual",loan:"loan",temp_rent:"temp_rent"}[i]||"individual";let l=null;if(o.customer_phone){let y=await s.prepare("SELECT id FROM customers WHERE phone = ?").bind(o.customer_phone).first();y?l=y.id:l=(await s.prepare(`
            INSERT INTO customers (name, phone, resident_number, address, created_at)
            VALUES (?, ?, ?, ?, datetime('now'))
          `).bind(o.customer_name||"미입력",o.customer_phone,o.resident_number||"",o.address||"").run()).meta.last_row_id}let m=null;o.plate_number&&(m=await s.prepare("SELECT id FROM motorcycles WHERE plate_number = ?").bind(o.plate_number).first()),!m&&o.vehicle_name&&(m=await s.prepare("SELECT id FROM motorcycles WHERE vehicle_name LIKE ?").bind("%"+o.vehicle_name+"%").first()),m||(m={id:(await s.prepare(`
          INSERT INTO motorcycles (
            plate_number, vehicle_name, driving_range, status, created_at
          ) VALUES (?, ?, ?, 'active', datetime('now'))
        `).bind(o.plate_number||"미등록",o.vehicle_name||"미입력","전연령").run()).meta.last_row_id});const b=({individual:"C",loan:"L",temp_rent:"TR"}[d]||"C")+Date.now()+Math.random().toString(36).substring(2,5),T={contract_type:i,source:o.source||"import",original_data:o};await s.prepare(`
        INSERT INTO contracts (
          contract_number, contract_type, motorcycle_id, customer_id,
          start_date, end_date, monthly_fee, deposit,
          contract_data, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', datetime('now'))
      `).bind(b,d,m.id,l,o.start_date||new Date().toISOString().split("T")[0],o.end_date||new Date().toISOString().split("T")[0],o.monthly_rent||o.daily_fee||0,o.deposit||0,JSON.stringify(T)).run(),r++,a[i]=(a[i]||0)+1}catch(i){console.error("Error importing contract:",i),n++}return e.json({success:r,failed:n,details:a,message:`리스: ${a.lease}건, 렌트: ${a.rent}건, 차용증: ${a.loan}건, 임시렌트: ${a.temp_rent}건`})});p.get("/api/temp-rent-contracts",async e=>{const s=e.env.DB||e.env.db,t=e.req.query("resident_number");let r=`
    SELECT 
      c.*,
      m.plate_number, m.vehicle_name,
      cu.name as customer_name, cu.phone, cu.resident_number
    FROM contracts c
    JOIN motorcycles m ON c.motorcycle_id = m.id
    LEFT JOIN customers cu ON c.customer_id = cu.id
    WHERE c.contract_type = 'temp_rent' AND c.deleted_at IS NULL
  `;const n=[];t&&(r+=" AND cu.resident_number = ?",n.push(t)),r+=" ORDER BY c.created_at DESC";const a=s.prepare(r),o=n.length>0?await a.bind(...n).all():await a.all();return e.json(o.results)});p.post("/api/temp-rent-contracts",f,async e=>{const s=e.env.DB||e.env.db,t=await e.req.json();try{const r=new Date().toISOString().split("T")[0].replace(/-/g,""),n=await s.prepare(`
      SELECT COUNT(*) as count FROM contracts 
      WHERE contract_number LIKE ?
    `).bind(`T-${r}-%`).first(),a=String(((n==null?void 0:n.count)||0)+1).padStart(4,"0"),o=`T-${r}-${a}`,i=await s.prepare("SELECT * FROM motorcycles WHERE id = ?").bind(t.motorcycle_id).first();if(!i)return e.json({error:"오토바이를 찾을 수 없습니다"},404);let c=null;if(t.phone){let _=await s.prepare("SELECT id FROM customers WHERE phone = ?").bind(t.phone).first();_?c=_.id:c=(await s.prepare(`
          INSERT INTO customers (name, phone, resident_number, created_at)
          VALUES (?, ?, ?, datetime('now'))
        `).bind(t.customer_name,t.phone,t.resident_number||"").run()).meta.last_row_id}const d={contract_type:"temp_rent",contract_number:o,motorcycle:{id:i.id,plate_number:i.plate_number,vehicle_name:i.vehicle_name},customer:{name:t.customer_name,phone:t.phone,resident_number:t.resident_number},period:{start_date:t.start_date,end_date:t.end_date},fees:{daily_fee:parseInt(t.daily_fee)||0},special_terms:t.special_terms,signature:t.signature,admin_id_card_photo:t.admin_id_card_photo,status:t.status||"active",created_at:new Date().toISOString()};console.log("🔄 [TempRent] Checking for existing active contracts for motorcycle:",t.motorcycle_id);const l=await s.prepare(`
      SELECT id, contract_number, status FROM contracts 
      WHERE motorcycle_id = ? AND status = 'active'
    `).bind(t.motorcycle_id).all();if(l.results.length>0){console.log(`📋 [TempRent] Found ${l.results.length} active personal contract(s), completing them...`);for(const _ of l.results)await s.prepare(`
          UPDATE contracts 
          SET status = 'completed', updated_at = CURRENT_TIMESTAMP 
          WHERE id = ?
        `).bind(_.id).run(),console.log(`✅ [TempRent] Completed personal contract: ${_.contract_number}`)}const m=await s.prepare(`
      SELECT id, contract_number, status FROM business_contracts 
      WHERE motorcycle_id = ? AND status = 'active'
    `).bind(t.motorcycle_id).all();if(m.results.length>0){console.log(`📋 [TempRent] Found ${m.results.length} active business contract(s), completing them...`);for(const _ of m.results)await s.prepare(`
          UPDATE business_contracts 
          SET status = 'completed', updated_at = CURRENT_TIMESTAMP 
          WHERE id = ?
        `).bind(_.id).run(),console.log(`✅ [TempRent] Completed business contract: ${_.contract_number}`)}return await s.prepare(`
      INSERT INTO contracts (
        contract_number, contract_type, motorcycle_id, customer_id,
        start_date, end_date, monthly_fee, deposit, special_terms,
        signature_data, id_card_photo, status, created_at
      ) VALUES (?, 'temp_rent', ?, ?, ?, ?, ?, 0, ?, ?, ?, 'active', datetime('now'))
    `).bind(o,t.motorcycle_id,c,t.start_date||new Date().toISOString().split("T")[0],t.end_date||new Date().toISOString().split("T")[0],parseInt(t.daily_fee)||0,t.special_terms||"",t.signature||"",t.admin_id_card_photo||"").run(),e.json({success:!0,contract_number:o,message:"임시렌트 계약서가 생성되었습니다"})}catch(r){return console.error("임시렌트 계약서 생성 실패:",r),e.json({error:"계약서 생성에 실패했습니다: "+r.message},500)}});p.post("/api/import/knox-cookie",f,async e=>{const{cookie:s}=await e.req.json();if(!s)return e.json({error:"쿠키 값이 필요합니다"},400);try{console.log("🔍 KnoxHub 데이터 가져오기 시작..."),console.log("Cookie:",s.substring(0,10)+"...");const t=["https://zenio5827.cafe24.com/Knox_Project/Knox_Hub/index.php","https://zenio5827.cafe24.com/Knox_Project/Knox_Hub/main.php","https://zenio5827.cafe24.com/Knox_Project/Knox_Hub/motorcycle_list.php","https://zenio5827.cafe24.com/Knox_Project/Knox_Hub/bike_list.php","https://zenio5827.cafe24.com/Knox_Project/Knox_Hub/list.php","http://knoxhub.kro.kr/index.php","http://knoxhub.kro.kr/main.php"],r=[],n=[];let a=null;for(const o of t)try{console.log(`시도: ${o}`);const i=await fetch(o,{headers:{Cookie:`PHPSESSID=${s}`,"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}});if(i.ok){const c=await i.text();console.log(`✅ 응답 성공: ${o} (${c.length} bytes)`);const d=/(\d{2,3}[가-힣]\d{4}|[가-힣]{2}\d{2}[가-힣]\d{4})/g,l=[...new Set(c.match(d)||[])];if(console.log(`🏍️ 발견된 번호판: ${l.length}개`),l.length>0){a=o,l.forEach(m=>{r.push({plate_number:m,vehicle_name:"정보 없음 (수동 입력 필요)",chassis_number:"",mileage:0,model_year:new Date().getFullYear(),status:"active"})});break}}}catch(i){console.log(`❌ 실패: ${o} - ${i.message}`)}return r.length>0?(console.log(`✅ 총 ${r.length}대 발견 (from ${a})`),e.json({motorcycles:r,contracts:n,source:a,extracted_at:new Date().toISOString()})):(console.log("⚠️ 데이터를 찾지 못했습니다. JSON 업로드 방식을 사용해주세요."),e.json({error:"KnoxHub에서 데이터를 찾을 수 없습니다. JSON 업로드 방식을 사용해주세요.",motorcycles:[],contracts:[]},404))}catch(t){return console.error("KnoxHub 데이터 가져오기 실패:",t),e.json({error:"데이터 가져오기에 실패했습니다. JSON 업로드 방식을 사용해주세요.",motorcycles:[],contracts:[]},500)}});p.post("/api/import/analyze-pdfs",f,async e=>{try{const{files:s}=await e.req.json();if(!s||!Array.isArray(s)||s.length===0)return e.json({error:"PDF 파일이 필요합니다"},400);console.log(`📄 ${s.length}개의 PDF 파일 분석 시작...`);const t=[],r=[],n=new Set;for(const a of s)try{const o=a.data.split(",")[1]||a.data,i=atob(o);let c="";for(let j=0;j<i.length;j++){const D=i[j],me=D.charCodeAt(0);me>=32&&me<=126?c+=D:(me===10||me===13)&&(c+=" ")}console.log(`📝 파일 "${a.name}" 텍스트 추출 완료 (${c.length} 문자)`);let d="lease";c.includes("차용증")||c.includes("LOAN")?d="loan":c.includes("임시")||c.includes("단기")?d="temp_rent":c.includes("렌트")||c.includes("RENT")?d="rent":(c.includes("리스")||c.includes("LEASE"))&&(d="lease");const l=c.match(/([가-힣]{0,2}\d{2,3}[가-힣]\d{4})/g),m=l?l[0]:null,_=[/혼다\s*[A-Z]*\s*\d*/gi,/야마하\s*[A-Z]*\s*\d*/gi,/스즈키\s*[A-Z]*\s*\d*/gi,/PCX\s*\d*/gi,/XMAX\s*\d*/gi,/엑스맥스\s*\d*/gi,/포르자\s*\d*/gi];let h=null;for(const j of _){const D=c.match(j);if(D){h=D[0].trim();break}}const b=[/차용인[:\s]*([가-힣]{2,4})/,/계약자[:\s]*([가-힣]{2,4})/,/성명[:\s]*([가-힣]{2,4})/,/이름[:\s]*([가-힣]{2,4})/];let T=null;for(const j of b){const D=c.match(j);if(D&&D[1]){T=D[1].trim();break}}const y=c.match(/01[0-9]-?\d{3,4}-?\d{4}/),w=y?y[0].replace(/-/g,"").replace(/(\d{3})(\d{4})(\d{4})/,"$1-$2-$3"):null,S=c.match(/\d{6}-?\d{7}/),F=S?S[0]:null,C=[/월대여금[:\s]*([0-9,]+)/,/일차감금액[:\s]*([0-9,]+)/,/대여금[:\s]*([0-9,]+)/,/렌트비[:\s]*([0-9,]+)/];let M=null;for(const j of C){const D=c.match(j);if(D&&D[1]){M=parseInt(D[1].replace(/,/g,""));break}}const q=c.match(/보증금[:\s]*([0-9,]+)/),H=q?parseInt(q[1].replace(/,/g,"")):0,A=[/20\d{2}[-.]?\d{2}[-.]?\d{2}/g,/20\d{2}년\s*\d{1,2}월\s*\d{1,2}일/g],x=[];for(const j of A){const D=c.match(j);D&&D.forEach(me=>{const It=me.replace(/년\s*/g,"-").replace(/월\s*/g,"-").replace(/일/g,"").replace(/\./g,"-");x.push(It)})}const X=x[0]||new Date().toISOString().split("T")[0],P=x[1]||X;m&&!n.has(m)&&(n.add(m),t.push({plate_number:m,vehicle_name:h||"정보 없음",chassis_number:"",mileage:0,model_year:new Date().getFullYear(),status:"active"})),(m||T)&&r.push({contract_type:d,customer_name:T||"미입력",customer_phone:w||"",resident_number:F||"",vehicle_name:h||"정보 없음",plate_number:m||"미등록",start_date:X,end_date:P,monthly_rent:d==="temp_rent"?0:M||0,daily_fee:d==="temp_rent"&&M||0,deposit:H,address:"",special_terms:`${a.name}에서 자동 추출`,source:"pdf_upload"})}catch(o){console.error(`파일 "${a.name}" 처리 실패:`,o)}return console.log(`✅ 분석 완료: 오토바이 ${t.length}대, 계약서 ${r.length}건`),e.json({motorcycles:t,contracts:r,analyzed_files:s.length,success:!0,message:`${s.length}개 파일 분석 완료. 오토바이 ${t.length}대, 계약서 ${r.length}건 추출됨`})}catch(s){return console.error("PDF 분석 실패:",s),e.json({error:"PDF 분석에 실패했습니다: "+s.message,motorcycles:[],contracts:[]},500)}});p.get("/dashboard",e=>e.html(`
    <!DOCTYPE html>
    <html lang="ko">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Z-BIKE 전자계약서</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <style>
            body { font-family: 'Noto Sans KR', sans-serif; }
            .stat-card {
                transition: all 0.3s ease;
                cursor: pointer;
            }
            .stat-card:hover {
                transform: translateY(-5px);
                box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            }
        </style>
    </head>
    <body class="bg-gray-100">
        <!-- 헤더 -->
        <div class="bg-white shadow-md">
            <div class="container mx-auto px-4 py-4">
                <div class="flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-gray-800">
                        <i class="fas fa-tachometer-alt mr-2 text-blue-600"></i>
                        운영현황
                    </h1>
                    <div class="flex items-center space-x-4">
                        <!-- 슈퍼관리자 전용: 관리자 관리 버튼 -->
                        <a href="/static/admin-management.html" id="adminManagementBtn" class="hidden text-gray-600 hover:text-blue-600 font-medium">
                            <i class="fas fa-users-cog mr-1"></i>관리자 관리
                        </a>
                        <a href="/static/settings.html" class="text-gray-600 hover:text-blue-600 font-medium">
                            <i class="fas fa-cog mr-1"></i>설정
                        </a>
                        <div class="flex items-center space-x-2 px-3 py-2 bg-blue-50 rounded-lg border border-blue-200">
                            <i class="fas fa-user-shield text-blue-600"></i>
                            <span id="userRoleBadge" class="text-sm font-bold text-blue-700"></span>
                        </div>
                        <button onclick="logout()" class="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg font-medium transition">
                            <i class="fas fa-sign-out-alt mr-1"></i>로그아웃
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- 메인 콘텐츠 -->
        <div class="container mx-auto px-4 py-8">
            <!-- 운영 통계 카드 4개 -->
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                <!-- 총 바이크 -->
                <div class="stat-card bg-gradient-to-br from-blue-500 to-blue-600 text-white p-6 rounded-xl shadow-lg" 
                     onclick="filterByStatus('all')">
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-4xl"><i class="fas fa-motorcycle"></i></div>
                        <div class="text-right">
                            <div class="text-sm opacity-90">총 바이크</div>
                            <div id="totalCount" class="text-3xl font-bold">0</div>
                        </div>
                    </div>
                </div>

                <!-- 사용중 -->
                <div class="stat-card bg-gradient-to-br from-green-500 to-green-600 text-white p-6 rounded-xl shadow-lg" 
                     onclick="filterByStatus('rented')">
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-4xl"><i class="fas fa-check-circle"></i></div>
                        <div class="text-right">
                            <div class="text-sm opacity-90">사용중</div>
                            <div id="rentedCount" class="text-3xl font-bold">0</div>
                        </div>
                    </div>
                </div>

                <!-- 휴차중 -->
                <div class="stat-card bg-gradient-to-br from-yellow-500 to-yellow-600 text-white p-6 rounded-xl shadow-lg" 
                     onclick="filterByStatus('available')">
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-4xl"><i class="fas fa-pause-circle"></i></div>
                        <div class="text-right">
                            <div class="text-sm opacity-90">휴차중</div>
                            <div id="availableCount" class="text-3xl font-bold">0</div>
                        </div>
                    </div>
                </div>

                <!-- 수리중/폐지 -->
                <div class="stat-card bg-gradient-to-br from-red-500 to-red-600 text-white p-6 rounded-xl shadow-lg" 
                     onclick="filterByStatus('maintenance_scrapped')">
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-4xl"><i class="fas fa-tools"></i></div>
                        <div class="text-right">
                            <div class="text-sm opacity-90">수리중/폐지</div>
                            <div id="maintenanceCount" class="text-3xl font-bold">0</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 추가 통계 -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <!-- 오토바이 관리 -->
                <div class="bg-white p-6 rounded-xl shadow-md cursor-pointer hover:shadow-lg transition" onclick="window.location.href='/static/motorcycles.html'">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600 text-sm">오토바이 관리</p>
                            <p class="text-lg font-bold text-blue-600">바로가기</p>
                        </div>
                        <div class="text-3xl text-blue-600"><i class="fas fa-motorcycle"></i></div>
                    </div>
                </div>

                <!-- 총 고객 수 -->
                <div class="bg-white p-6 rounded-xl shadow-md">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600 text-sm">총 고객</p>
                            <p id="totalCustomers" class="text-2xl font-bold text-gray-800">0</p>
                        </div>
                        <div class="text-3xl text-green-600"><i class="fas fa-users"></i></div>
                    </div>
                </div>

                <!-- 차용 대금 -->
                <div class="bg-white p-6 rounded-xl shadow-md">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600 text-sm">차용 대금</p>
                            <p id="totalLoanAmount" class="text-2xl font-bold text-gray-800">0원</p>
                        </div>
                        <div class="text-3xl text-orange-600"><i class="fas fa-file-invoice-dollar"></i></div>
                    </div>
                </div>
            </div>

            <!-- 빠른 액세스 -->
            <div class="bg-white p-6 rounded-xl shadow-md">
                <h2 class="text-xl font-bold mb-4 text-gray-800">
                    <i class="fas fa-bolt mr-2 text-yellow-500"></i>빠른 액세스
                </h2>
                <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <!-- Row 1 -->
                    <a href="/static/motorcycle-register.html" class="bg-blue-50 hover:bg-blue-100 p-4 rounded-lg text-center transition">
                        <i class="fas fa-plus-circle text-3xl text-blue-600 mb-2"></i>
                        <p class="text-sm font-medium text-gray-700">오토바이 등록</p>
                    </a>
                    <a href="/static/customer-register.html" class="bg-cyan-50 hover:bg-cyan-100 p-4 rounded-lg text-center transition">
                        <i class="fas fa-user-plus text-3xl text-cyan-600 mb-2"></i>
                        <p class="text-sm font-medium text-gray-700">고객 등록</p>
                    </a>
                    <a href="/static/companies-new.html" class="bg-indigo-50 hover:bg-indigo-100 p-4 rounded-lg text-center transition">
                        <i class="fas fa-building text-3xl text-indigo-600 mb-2"></i>
                        <p class="text-sm font-medium text-gray-700">업체 등록</p>
                    </a>
                    <a href="/static/contract-new.html" class="bg-green-50 hover:bg-green-100 p-4 rounded-lg text-center transition">
                        <i class="fas fa-file-signature text-3xl text-green-600 mb-2"></i>
                        <p class="text-sm font-medium text-gray-700">개인계약서 작성</p>
                    </a>
                    <a href="/static/business-contract-new.html" class="bg-teal-50 hover:bg-teal-100 p-4 rounded-lg text-center transition">
                        <i class="fas fa-handshake text-3xl text-teal-600 mb-2"></i>
                        <p class="text-sm font-medium text-gray-700">업체계약서 작성</p>
                    </a>
                    
                    <!-- Row 2 -->
                    <a href="/static/loan-new.html" class="bg-yellow-50 hover:bg-yellow-100 p-4 rounded-lg text-center transition">
                        <i class="fas fa-file-invoice-dollar text-3xl text-yellow-600 mb-2"></i>
                        <p class="text-sm font-medium text-gray-700">차용증 작성</p>
                    </a>
                    <a href="/static/customers.html" class="bg-blue-50 hover:bg-blue-100 p-4 rounded-lg text-center transition">
                        <i class="fas fa-users text-3xl text-blue-600 mb-2"></i>
                        <p class="text-sm font-medium text-gray-700">고객 목록</p>
                    </a>
                    <a href="/static/contracts.html" class="bg-orange-50 hover:bg-orange-100 p-4 rounded-lg text-center transition">
                        <i class="fas fa-folder-open text-3xl text-orange-600 mb-2"></i>
                        <p class="text-sm font-medium text-gray-700">계약서 목록</p>
                    </a>
                    <a href="/static/loans.html" class="bg-red-50 hover:bg-red-100 p-4 rounded-lg text-center transition">
                        <i class="fas fa-receipt text-3xl text-red-600 mb-2"></i>
                        <p class="text-sm font-medium text-gray-700">차용증 목록</p>
                    </a>
                </div>
            </div>
        </div>

        <!-- 관리자 관리 모달 (슈퍼관리자 전용) -->
        <div id="adminManagementModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
            <div class="bg-white rounded-xl shadow-2xl p-8 max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold text-gray-800">
                        <i class="fas fa-users-cog mr-2 text-blue-600"></i>관리자 관리
                    </h2>
                    <button onclick="closeAdminManagement()" class="text-gray-500 hover:text-gray-700 text-2xl">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <div id="adminList" class="space-y-4">
                    <!-- 관리자 목록이 여기에 동적으로 로드됩니다 -->
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"><\/script>
        <script>
            // Axios 인터셉터 설정 - 세션 ID 자동 추가 (동적으로 읽기)
            axios.interceptors.request.use(config => {
                const sessionId = localStorage.getItem('sessionId');
                console.log('🔍 [Axios Interceptor] SessionID:', sessionId);
                console.log('🔍 [Axios Interceptor] Request URL:', config.url);
                if (sessionId) {
                    config.headers['X-Session-ID'] = sessionId;
                    console.log('✅ [Axios Interceptor] X-Session-ID 헤더 추가됨');
                } else {
                    console.log('❌ [Axios Interceptor] SessionID 없음 - 헤더 추가 안됨');
                }
                return config;
            });

            axios.interceptors.response.use(
                response => response,
                error => {
                    if (error.response?.status === 401) {
                        // 인증 실패 시 로그인 페이지로 이동
                        localStorage.removeItem('sessionId');
                        localStorage.removeItem('user');
                        window.location.href = '/static/login.html';
                    }
                    return Promise.reject(error);
                }
            );

            // 통계 로드
            async function loadStats() {
                try {
                    const response = await axios.get('/api/dashboard/stats');
                    const data = response.data;
                    
                    // 오토바이 통계
                    const total = data.motorcycles.total;
                    const rented = data.motorcycles.rented;  // 진행중 계약서 개수
                    const available = data.motorcycles.available;  // 휴차중
                    const maintenance = data.motorcycles.maintenance;  // 수리중/폐지 합계
                    
                    document.getElementById('totalCount').textContent = total;
                    document.getElementById('rentedCount').textContent = rented;
                    document.getElementById('availableCount').textContent = available;
                    document.getElementById('maintenanceCount').textContent = maintenance;
                    
                    // 고객 및 차용증 통계
                    document.getElementById('totalCustomers').textContent = data.customers;
                    document.getElementById('totalLoanAmount').textContent = 
                        (data.contracts.total_loan_amount || 0).toLocaleString() + '원';
                } catch (error) {
                    console.error('통계 로드 실패:', error);
                    if (error.response?.status === 401) {
                        alert('⚠️ 로그인이 필요합니다.');
                    }
                }
            }
            
            // 상태별 필터링 (오토바이 관리 페이지로 이동)
            function filterByStatus(status) {
                window.location.href = '/static/motorcycles.html?status=' + status;
            }
            
            // 페이지 로드 시 인증 확인 및 통계 로드
            (async function() {
                const sessionId = localStorage.getItem('sessionId');
                const userStr = localStorage.getItem('user');
                
                if (!sessionId) {
                    console.log('❌ 세션 없음 - 로그인 페이지로 이동');
                    window.location.href = '/static/login.html';
                    return;
                }
                
                // 사용자 역할 표시
                if (userStr) {
                    try {
                        const user = JSON.parse(userStr);
                        const roleBadge = document.getElementById('userRoleBadge');
                        if (roleBadge) {
                            const roleText = user.role === 'superadmin' ? '슈퍼관리자' : '관리자';
                            const userName = user.name || user.username;
                            roleBadge.textContent = \`\${userName} (\${roleText})\`;
                        }
                        
                        // 슈퍼관리자일 때만 "관리자 관리" 버튼 표시
                        if (user.role === 'superadmin') {
                            const adminManagementBtn = document.getElementById('adminManagementBtn');
                            if (adminManagementBtn) {
                                adminManagementBtn.classList.remove('hidden');
                            }
                        }
                    } catch (e) {
                        console.error('사용자 정보 파싱 오류:', e);
                    }
                }
                
                console.log('✅ 세션 확인:', sessionId);
                await loadStats();
            })();
            
            // 10분마다 세션 자동 갱신
            setInterval(async () => {
                const sessionId = localStorage.getItem('sessionId');
                if (sessionId) {
                    try {
                        await axios.get('/api/auth/check', {
                            headers: { 'X-Session-ID': sessionId }
                        });
                        console.log('✅ 세션 자동 갱신 성공');
                    } catch (error) {
                        console.error('❌ 세션 자동 갱신 실패:', error);
                    }
                }
            }, 10 * 60 * 1000);
            
            // 5분마다 통계 자동 새로고침
            setInterval(loadStats, 5 * 60 * 1000);

            // ========================================
            // 로그아웃 기능
            // ========================================
            function logout() {
                if (confirm('로그아웃하시겠습니까?')) {
                    // 세션 ID 삭제
                    localStorage.removeItem('sessionId');
                    localStorage.removeItem('user');
                    
                    // 로그인 페이지로 이동
                    window.location.href = '/static/login.html';
                }
            }
            
            // 전역 함수로 등록
            window.logout = logout;

            // ========================================
            // 계약자 정보 관리 함수
            // ========================================

            // Daum 우편번호 검색
            function searchAddress() {
                new daum.Postcode({
                    oncomplete: function(data) {
                        // 우편번호와 주소 정보를 필드에 입력
                        document.getElementById('customerPostcode').value = data.zonecode;
                        
                        // 기본 주소 (도로명 또는 지번)
                        let fullAddress = '';
                        if (data.userSelectedType === 'R') { // 도로명 주소
                            fullAddress = data.roadAddress;
                        } else { // 지번 주소
                            fullAddress = data.jibunAddress;
                        }
                        
                        // 건물명 추가
                        if (data.buildingName !== '') {
                            fullAddress += ' (' + data.buildingName + ')';
                        }
                        
                        document.getElementById('customerAddress').value = fullAddress;
                        
                        // 상세주소 입력 필드에 포커스
                        document.getElementById('customerDetailAddress').focus();
                    }
                }).open();
            }

            // 주민등록번호 자동 하이픈 추가 (입력 및 붙여넣기 모두 처리)
            function formatResidentNumber(value) {
                let numbers = value.replace(/[^0-9]/g, '');
                numbers = numbers.substring(0, 13);
                if (numbers.length > 6) {
                    return numbers.substring(0, 6) + '-' + numbers.substring(6);
                }
                return numbers;
            }

            const residentNumberInput = document.getElementById('customerResidentNumber');
            if (residentNumberInput) {
                residentNumberInput.addEventListener('input', function(e) {
                    e.target.value = formatResidentNumber(e.target.value);
                });

                residentNumberInput.addEventListener('paste', function(e) {
                    e.preventDefault();
                    const pastedText = (e.clipboardData || window.clipboardData).getData('text');
                    e.target.value = formatResidentNumber(pastedText);
                });
            }

            // 전화번호 자동 하이픈 추가 (입력 및 붙여넣기 모두 처리)
            function formatPhoneNumber(value) {
                let numbers = value.replace(/[^0-9]/g, '');
                numbers = numbers.substring(0, 11);
                if (numbers.length > 3 && numbers.length <= 7) {
                    return numbers.substring(0, 3) + '-' + numbers.substring(3);
                } else if (numbers.length > 7) {
                    return numbers.substring(0, 3) + '-' + numbers.substring(3, 7) + '-' + numbers.substring(7);
                }
                return numbers;
            }

            const phoneInput = document.getElementById('customerPhone');
            if (phoneInput) {
                phoneInput.addEventListener('input', function(e) {
                    e.target.value = formatPhoneNumber(e.target.value);
                });

                phoneInput.addEventListener('paste', function(e) {
                    e.preventDefault();
                    const pastedText = (e.clipboardData || window.clipboardData).getData('text');
                    e.target.value = formatPhoneNumber(pastedText);
                });
            }

            // 폼 초기화
            function clearCustomerForm() {
                document.getElementById('customerForm').reset();
            }

            // 계약자 폼 토글 (표시/숨김)
            function toggleCustomerForm() {
                const section = document.getElementById('customerFormSection');
                if (section.classList.contains('hidden')) {
                    section.classList.remove('hidden');
                    section.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    setTimeout(() => {
                        document.getElementById('customerName').focus();
                    }, 500);
                } else {
                    section.classList.add('hidden');
                }
            }

            // 폼 제출 처리
            const customerForm = document.getElementById('customerForm');
            if (customerForm) {
                customerForm.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    
                    const sessionId = localStorage.getItem('sessionId');
                    if (!sessionId) {
                        alert('⚠️ 로그인이 필요합니다.');
                        window.location.href = '/static/login.html';
                        return;
                    }

                    const customerData = {
                        name: document.getElementById('customerName').value.trim(),
                        resident_number: document.getElementById('customerResidentNumber').value.trim(),
                        phone: document.getElementById('customerPhone').value.trim(),
                        postcode: document.getElementById('customerPostcode').value.trim(),
                        address: document.getElementById('customerAddress').value.trim(),
                        detail_address: document.getElementById('customerDetailAddress').value.trim() || '',
                        license_type: '보통' // 기본값
                };

                // 유효성 검사
                if (!customerData.name) {
                    alert('이름을 입력하세요.');
                    return;
                }
                if (!customerData.resident_number || customerData.resident_number.length !== 14) {
                    alert('주민등록번호를 정확히 입력하세요. (123456-1234567)');
                    return;
                }
                if (!customerData.phone) {
                    alert('전화번호를 입력하세요.');
                    return;
                }
                if (!document.getElementById('customerPostcode').value) {
                    alert('우편번호를 검색하세요.');
                    return;
                }

                try {
                    const response = await fetch('/api/customers', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Session-ID': sessionId
                        },
                        body: JSON.stringify(customerData)
                    });

                    if (!response.ok) {
                        const error = await response.json();
                        throw new Error(error.error || '저장 실패');
                    }

                    const result = await response.json();
                    alert('✅ 계약자 정보가 저장되었습니다.\\n\\n이름: ' + customerData.name + '\\n전화번호: ' + customerData.phone);
                    
                    // 폼 초기화
                    clearCustomerForm();
                    
                    // 폼 섹션 닫기
                    document.getElementById('customerFormSection').classList.add('hidden');
                } catch (error) {
                    console.error('Error:', error);
                    alert('❌ 저장 실패: ' + error.message);
                }
            });
            }
        <\/script>
        <!-- Daum 우편번호 API -->
        <script src="https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"><\/script>
    </body>
    </html>
  `));const nt=new Dt,xs=Object.assign({"/src/index.tsx":p});let Ot=!1;for(const[,e]of Object.entries(xs))e&&(nt.all("*",s=>{let t;try{t=s.executionCtx}catch{}return e.fetch(s.req.raw,s.env,t)}),nt.notFound(s=>{let t;try{t=s.executionCtx}catch{}return e.fetch(s.req.raw,s.env,t)}),Ot=!0);if(!Ot)throw new Error("Can't import modules from ['/src/index.ts','/src/index.tsx','/app/server.ts']");export{nt as default};
